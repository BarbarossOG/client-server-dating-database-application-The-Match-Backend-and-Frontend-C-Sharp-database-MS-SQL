﻿namespace TheMatch
{
    partial class ShowAnket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonBackEditDostup = new System.Windows.Forms.Button();
            this.labelNameUser = new System.Windows.Forms.Label();
            this.labelTypeOcenka = new System.Windows.Forms.Label();
            this.buttonVzaimnosti = new System.Windows.Forms.Button();
            this.buttonOcenka = new System.Windows.Forms.Button();
            this.comboBoxTypeOcenki = new System.Windows.Forms.ComboBox();
            this.textBoxUserName = new System.Windows.Forms.TextBox();
            this.buttonNextAnketa = new System.Windows.Forms.Button();
            this.pictureBoxAvatar = new System.Windows.Forms.PictureBox();
            this.textBoxID = new System.Windows.Forms.TextBox();
            this.labelID = new System.Windows.Forms.Label();
            this.textBoxAge = new System.Windows.Forms.TextBox();
            this.labelAge = new System.Windows.Forms.Label();
            this.listBoxUserHobbies = new System.Windows.Forms.ListBox();
            this.buttonCheckActivity = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAvatar)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonBackEditDostup
            // 
            this.buttonBackEditDostup.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.buttonBackEditDostup.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonBackEditDostup.ForeColor = System.Drawing.Color.White;
            this.buttonBackEditDostup.Location = new System.Drawing.Point(21, 396);
            this.buttonBackEditDostup.Margin = new System.Windows.Forms.Padding(2);
            this.buttonBackEditDostup.Name = "buttonBackEditDostup";
            this.buttonBackEditDostup.Size = new System.Drawing.Size(110, 35);
            this.buttonBackEditDostup.TabIndex = 0;
            this.buttonBackEditDostup.Text = "Назад";
            this.buttonBackEditDostup.UseVisualStyleBackColor = false;
            this.buttonBackEditDostup.Click += new System.EventHandler(this.buttonBackMenuUserAnket_Click);
            // 
            // labelNameUser
            // 
            this.labelNameUser.AutoSize = true;
            this.labelNameUser.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelNameUser.Location = new System.Drawing.Point(523, 12);
            this.labelNameUser.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelNameUser.Name = "labelNameUser";
            this.labelNameUser.Size = new System.Drawing.Size(43, 21);
            this.labelNameUser.TabIndex = 1;
            this.labelNameUser.Text = "Имя";
            // 
            // labelTypeOcenka
            // 
            this.labelTypeOcenka.AutoSize = true;
            this.labelTypeOcenka.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelTypeOcenka.Location = new System.Drawing.Point(288, 278);
            this.labelTypeOcenka.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTypeOcenka.Name = "labelTypeOcenka";
            this.labelTypeOcenka.Size = new System.Drawing.Size(100, 21);
            this.labelTypeOcenka.TabIndex = 1;
            this.labelTypeOcenka.Text = "Тип оценки";
            // 
            // buttonVzaimnosti
            // 
            this.buttonVzaimnosti.BackColor = System.Drawing.Color.LightCoral;
            this.buttonVzaimnosti.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonVzaimnosti.ForeColor = System.Drawing.Color.White;
            this.buttonVzaimnosti.Location = new System.Drawing.Point(21, 81);
            this.buttonVzaimnosti.Margin = new System.Windows.Forms.Padding(2);
            this.buttonVzaimnosti.Name = "buttonVzaimnosti";
            this.buttonVzaimnosti.Size = new System.Drawing.Size(175, 44);
            this.buttonVzaimnosti.TabIndex = 2;
            this.buttonVzaimnosti.Text = "Взаимности";
            this.buttonVzaimnosti.UseVisualStyleBackColor = false;
            this.buttonVzaimnosti.Click += new System.EventHandler(this.buttonVzaimnosti_Click);
            // 
            // buttonOcenka
            // 
            this.buttonOcenka.BackColor = System.Drawing.Color.LightCoral;
            this.buttonOcenka.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonOcenka.ForeColor = System.Drawing.Color.White;
            this.buttonOcenka.Location = new System.Drawing.Point(281, 387);
            this.buttonOcenka.Margin = new System.Windows.Forms.Padding(2);
            this.buttonOcenka.Name = "buttonOcenka";
            this.buttonOcenka.Size = new System.Drawing.Size(98, 44);
            this.buttonOcenka.TabIndex = 3;
            this.buttonOcenka.Text = "Оценить";
            this.buttonOcenka.UseVisualStyleBackColor = false;
            this.buttonOcenka.Click += new System.EventHandler(this.buttonOcenka_Click);
            // 
            // comboBoxTypeOcenki
            // 
            this.comboBoxTypeOcenki.FormattingEnabled = true;
            this.comboBoxTypeOcenki.Location = new System.Drawing.Point(281, 309);
            this.comboBoxTypeOcenki.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxTypeOcenki.Name = "comboBoxTypeOcenki";
            this.comboBoxTypeOcenki.Size = new System.Drawing.Size(115, 21);
            this.comboBoxTypeOcenki.TabIndex = 5;
            // 
            // textBoxUserName
            // 
            this.textBoxUserName.Location = new System.Drawing.Point(475, 35);
            this.textBoxUserName.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxUserName.Name = "textBoxUserName";
            this.textBoxUserName.Size = new System.Drawing.Size(139, 20);
            this.textBoxUserName.TabIndex = 6;
            // 
            // buttonNextAnketa
            // 
            this.buttonNextAnketa.BackColor = System.Drawing.Color.LightCoral;
            this.buttonNextAnketa.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonNextAnketa.ForeColor = System.Drawing.Color.White;
            this.buttonNextAnketa.Location = new System.Drawing.Point(527, 396);
            this.buttonNextAnketa.Margin = new System.Windows.Forms.Padding(2);
            this.buttonNextAnketa.Name = "buttonNextAnketa";
            this.buttonNextAnketa.Size = new System.Drawing.Size(110, 35);
            this.buttonNextAnketa.TabIndex = 7;
            this.buttonNextAnketa.Text = "Далее";
            this.buttonNextAnketa.UseVisualStyleBackColor = false;
            this.buttonNextAnketa.Click += new System.EventHandler(this.buttonNextAnketa_Click);
            // 
            // pictureBoxAvatar
            // 
            this.pictureBoxAvatar.Location = new System.Drawing.Point(257, 9);
            this.pictureBoxAvatar.Name = "pictureBoxAvatar";
            this.pictureBoxAvatar.Size = new System.Drawing.Size(168, 189);
            this.pictureBoxAvatar.TabIndex = 8;
            this.pictureBoxAvatar.TabStop = false;
            // 
            // textBoxID
            // 
            this.textBoxID.Location = new System.Drawing.Point(301, 228);
            this.textBoxID.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxID.Name = "textBoxID";
            this.textBoxID.ReadOnly = true;
            this.textBoxID.Size = new System.Drawing.Size(69, 20);
            this.textBoxID.TabIndex = 10;
            // 
            // labelID
            // 
            this.labelID.AutoSize = true;
            this.labelID.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelID.Location = new System.Drawing.Point(322, 202);
            this.labelID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelID.Name = "labelID";
            this.labelID.Size = new System.Drawing.Size(27, 21);
            this.labelID.TabIndex = 9;
            this.labelID.Text = "ID";
            // 
            // textBoxAge
            // 
            this.textBoxAge.Location = new System.Drawing.Point(475, 96);
            this.textBoxAge.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxAge.Name = "textBoxAge";
            this.textBoxAge.Size = new System.Drawing.Size(139, 20);
            this.textBoxAge.TabIndex = 12;
            // 
            // labelAge
            // 
            this.labelAge.AutoSize = true;
            this.labelAge.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelAge.Location = new System.Drawing.Point(505, 73);
            this.labelAge.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelAge.Name = "labelAge";
            this.labelAge.Size = new System.Drawing.Size(74, 21);
            this.labelAge.TabIndex = 11;
            this.labelAge.Text = "Возраст";
            // 
            // listBoxUserHobbies
            // 
            this.listBoxUserHobbies.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.listBoxUserHobbies.FormattingEnabled = true;
            this.listBoxUserHobbies.ItemHeight = 16;
            this.listBoxUserHobbies.Location = new System.Drawing.Point(475, 150);
            this.listBoxUserHobbies.Name = "listBoxUserHobbies";
            this.listBoxUserHobbies.Size = new System.Drawing.Size(162, 164);
            this.listBoxUserHobbies.TabIndex = 13;
            // 
            // buttonCheckActivity
            // 
            this.buttonCheckActivity.BackColor = System.Drawing.Color.LightCoral;
            this.buttonCheckActivity.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonCheckActivity.ForeColor = System.Drawing.Color.White;
            this.buttonCheckActivity.Location = new System.Drawing.Point(21, 12);
            this.buttonCheckActivity.Margin = new System.Windows.Forms.Padding(2);
            this.buttonCheckActivity.Name = "buttonCheckActivity";
            this.buttonCheckActivity.Size = new System.Drawing.Size(175, 44);
            this.buttonCheckActivity.TabIndex = 14;
            this.buttonCheckActivity.Text = "Взаимодействие";
            this.buttonCheckActivity.UseVisualStyleBackColor = false;
            this.buttonCheckActivity.Click += new System.EventHandler(this.buttonCheckActivity_Click);
            // 
            // ShowAnket
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(662, 449);
            this.Controls.Add(this.buttonCheckActivity);
            this.Controls.Add(this.listBoxUserHobbies);
            this.Controls.Add(this.textBoxAge);
            this.Controls.Add(this.labelAge);
            this.Controls.Add(this.textBoxID);
            this.Controls.Add(this.labelID);
            this.Controls.Add(this.pictureBoxAvatar);
            this.Controls.Add(this.buttonNextAnketa);
            this.Controls.Add(this.textBoxUserName);
            this.Controls.Add(this.comboBoxTypeOcenki);
            this.Controls.Add(this.buttonOcenka);
            this.Controls.Add(this.buttonVzaimnosti);
            this.Controls.Add(this.labelTypeOcenka);
            this.Controls.Add(this.labelNameUser);
            this.Controls.Add(this.buttonBackEditDostup);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ShowAnket";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Просмотр анкет";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAvatar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBackEditDostup;
        private System.Windows.Forms.Label labelNameUser;
        private System.Windows.Forms.Label labelTypeOcenka;
        private System.Windows.Forms.Button buttonVzaimnosti;
        private System.Windows.Forms.Button buttonOcenka;
        private System.Windows.Forms.ComboBox comboBoxTypeOcenki;
        private System.Windows.Forms.TextBox textBoxUserName;
        private System.Windows.Forms.Button buttonNextAnketa;
        private System.Windows.Forms.PictureBox pictureBoxAvatar;
        private System.Windows.Forms.TextBox textBoxID;
        private System.Windows.Forms.Label labelID;
        private System.Windows.Forms.TextBox textBoxAge;
        private System.Windows.Forms.Label labelAge;
        private System.Windows.Forms.ListBox listBoxUserHobbies;
        private System.Windows.Forms.Button buttonCheckActivity;
    }
}