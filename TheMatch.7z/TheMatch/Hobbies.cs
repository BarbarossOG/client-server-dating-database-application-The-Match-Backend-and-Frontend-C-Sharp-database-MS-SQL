﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TheMatch
{
    public partial class Hobbies : Form
    {
        private string connectionString = "Server = DESKTOP-E7PFLIN\\SQLEXPRESS;" +
                                          "Initial Catalog = Erimeev_1415_TheMatch;" +
                                          "Integrated Security = True;";

        public Hobbies()
        {
            InitializeComponent();
        }

        private void Hobbies_Load(object sender, EventArgs e)
        {
            LoadHobbies();
            LoadUserHobbies();
        }

        private void buttonBackInteres_Click(object sender, EventArgs e)
        {
            MenuUser menuUser = new MenuUser();
            menuUser.Show();
            this.Hide();
        }

        private void LoadUserHobbies()
        {
            int userID = GetUserIDByEmail(CurrentUser.Email);

            if (userID > 0)
            {
                listBoxUserHobbies.Items.Clear();

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT Название_увлечения FROM Пользователи_Названия_Увлечений WHERE ID_Пользователя = @UserID";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", userID);
                        connection.Open();

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                listBoxUserHobbies.Items.Add(reader["Название_увлечения"].ToString());
                            }
                        }
                    }
                }
            }
        }

        private void LoadHobbies()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Название_увлечения FROM Увлечения";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            comboBoxHobbies.Items.Add(reader["Название_увлечения"].ToString());
                        }
                    }
                }
            }
        }

        private int GetUserIDByEmail(string email)
        {
            int userID = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT ID_Пользователя FROM Пользователи WHERE Электронная_почта = @Email";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Email", email);
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            userID = Convert.ToInt32(reader["ID_Пользователя"]);
                        }
                    }
                }
            }
            return userID;
        }

        private int GetHobbyIDByName(string hobbyName)
        {
            int hobbyID = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT ID_Увлечения FROM Увлечения WHERE Название_увлечения = @HobbyName";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@HobbyName", hobbyName);
                    connection.Open();

                    object result = command.ExecuteScalar();
                    if (result != null)
                    {
                        hobbyID = Convert.ToInt32(result);
                    }
                }
            }
            return hobbyID;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            string selectedHobby = comboBoxHobbies.SelectedItem?.ToString();
            if (selectedHobby != null)
            {
                int userID = GetUserIDByEmail(CurrentUser.Email);
                int hobbyID = GetHobbyIDByName(selectedHobby);

                if (userID > 0 && hobbyID > 0)
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        try
                        {
                            connection.Open();
                            SqlCommand command = new SqlCommand("AddHobbiesUser", connection);
                            command.CommandType = CommandType.StoredProcedure;
                            command.Parameters.AddWithValue("@ID_Пользователя", userID);
                            command.Parameters.AddWithValue("@ID_Увлечения", hobbyID);
                            command.ExecuteNonQuery();

                            MessageBox.Show("Увлечение успешно добавлено", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadUserHobbies(); // Обновляем список увлечений пользователя
                        }
                        catch (SqlException ex)
                        {
                            if (ex.Number == 50000) // Пользовательские ошибки из RAISERROR
                            {
                                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else
                            {
                                MessageBox.Show("Ошибка SQL: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Ошибка при добавлении увлечения: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            string selectedHobby = listBoxUserHobbies.SelectedItem?.ToString();
            if (selectedHobby != null)
            {
                int userID = GetUserIDByEmail(CurrentUser.Email);
                int hobbyID = GetHobbyIDByName(selectedHobby);

                if (userID > 0 && hobbyID > 0)
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        try
                        {
                            connection.Open();
                            SqlCommand command = new SqlCommand("DeleteHobbiesUser", connection);
                            command.CommandType = CommandType.StoredProcedure;
                            command.Parameters.AddWithValue("@ID_Пользователя", userID);
                            command.Parameters.AddWithValue("@ID_Увлечения", hobbyID);
                            command.ExecuteNonQuery();

                            MessageBox.Show("Увлечение успешно удалено", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadUserHobbies(); // Обновляем список увлечений пользователя
                        }
                        catch (SqlException ex)
                        {
                            if (ex.Number == 50000) // Пользовательские ошибки из RAISERROR
                            {
                                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else
                            {
                                MessageBox.Show("Ошибка SQL: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Ошибка при удалении увлечения: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }
    }
}
