﻿namespace TheMatch
{
    partial class Vzaimnosti
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxUserVzaimnosti = new System.Windows.Forms.ListBox();
            this.labelInfo = new System.Windows.Forms.Label();
            this.buttonBackVzaimki = new System.Windows.Forms.Button();
            this.buttonUpdateVzaimki = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBoxUserVzaimnosti
            // 
            this.listBoxUserVzaimnosti.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.listBoxUserVzaimnosti.FormattingEnabled = true;
            this.listBoxUserVzaimnosti.ItemHeight = 20;
            this.listBoxUserVzaimnosti.Location = new System.Drawing.Point(100, 86);
            this.listBoxUserVzaimnosti.Name = "listBoxUserVzaimnosti";
            this.listBoxUserVzaimnosti.Size = new System.Drawing.Size(345, 164);
            this.listBoxUserVzaimnosti.TabIndex = 24;
            // 
            // labelInfo
            // 
            this.labelInfo.AutoSize = true;
            this.labelInfo.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelInfo.ForeColor = System.Drawing.Color.LightCoral;
            this.labelInfo.Location = new System.Drawing.Point(45, 45);
            this.labelInfo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelInfo.Name = "labelInfo";
            this.labelInfo.Size = new System.Drawing.Size(454, 23);
            this.labelInfo.TabIndex = 19;
            this.labelInfo.Text = "Эти пользователи ответили вам взаимностью:";
            // 
            // buttonBackVzaimki
            // 
            this.buttonBackVzaimki.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.buttonBackVzaimki.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonBackVzaimki.ForeColor = System.Drawing.Color.White;
            this.buttonBackVzaimki.Location = new System.Drawing.Point(33, 392);
            this.buttonBackVzaimki.Margin = new System.Windows.Forms.Padding(2);
            this.buttonBackVzaimki.Name = "buttonBackVzaimki";
            this.buttonBackVzaimki.Size = new System.Drawing.Size(100, 32);
            this.buttonBackVzaimki.TabIndex = 18;
            this.buttonBackVzaimki.Text = "Назад";
            this.buttonBackVzaimki.UseVisualStyleBackColor = false;
            this.buttonBackVzaimki.Click += new System.EventHandler(this.buttonBackVzaimki_Click);
            // 
            // buttonUpdateVzaimki
            // 
            this.buttonUpdateVzaimki.BackColor = System.Drawing.Color.LightCoral;
            this.buttonUpdateVzaimki.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonUpdateVzaimki.ForeColor = System.Drawing.Color.White;
            this.buttonUpdateVzaimki.Location = new System.Drawing.Point(206, 277);
            this.buttonUpdateVzaimki.Margin = new System.Windows.Forms.Padding(2);
            this.buttonUpdateVzaimki.Name = "buttonUpdateVzaimki";
            this.buttonUpdateVzaimki.Size = new System.Drawing.Size(100, 32);
            this.buttonUpdateVzaimki.TabIndex = 25;
            this.buttonUpdateVzaimki.Text = "Обновить";
            this.buttonUpdateVzaimki.UseVisualStyleBackColor = false;
            this.buttonUpdateVzaimki.Click += new System.EventHandler(this.buttonUpdateVzaimki_Click);
            // 
            // Vzaimnosti
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(535, 450);
            this.Controls.Add(this.buttonUpdateVzaimki);
            this.Controls.Add(this.listBoxUserVzaimnosti);
            this.Controls.Add(this.labelInfo);
            this.Controls.Add(this.buttonBackVzaimki);
            this.Location = new System.Drawing.Point(21, 81);
            this.Name = "Vzaimnosti";
            this.Text = "Ваши взаимности";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxUserVzaimnosti;
        private System.Windows.Forms.Label labelInfo;
        private System.Windows.Forms.Button buttonBackVzaimki;
        private System.Windows.Forms.Button buttonUpdateVzaimki;
    }
}