﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheMatch
{
    public partial class MenuModerator : Form
    {
        public MenuModerator()
        {
            InitializeComponent();
        }

        private void buttonBackModerator_Click(object sender, EventArgs e)
        {
            StartPage startpage = new StartPage();
            startpage.Show();
            this.Hide();
        }

        private void buttonEditUser_Click(object sender, EventArgs e)
        {
            Users users = new Users();
            users.Show();
            this.Hide();
        }

        private void buttonOtchet_Click(object sender, EventArgs e)
        {
            Otchet otchet = new Otchet();
            otchet.Show();
            this.Hide();
        }
     }
}


