﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheMatch
{
    public partial class Otchet : Form
    {
        public Otchet()
        {
            InitializeComponent();
        }

        private void buttonBackModerator_Click(object sender, EventArgs e)
        {
            MenuModerator menumoderator = new MenuModerator();
            menumoderator.Show();
            this.Hide();
        }

        private void Otchet_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "erimeev_1415_TheMatchDataSet.НеактивныеПользователи". При необходимости она может быть перемещена или удалена.
            this.неактивныеПользователиTableAdapter.Fill(this.erimeev_1415_TheMatchDataSet.НеактивныеПользователи);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "erimeev_1415_TheMatchDataSet.Принятые_предложения". При необходимости она может быть перемещена или удалена.
            this.принятые_предложенияTableAdapter.Fill(this.erimeev_1415_TheMatchDataSet.Принятые_предложения);

        }
    }
}
