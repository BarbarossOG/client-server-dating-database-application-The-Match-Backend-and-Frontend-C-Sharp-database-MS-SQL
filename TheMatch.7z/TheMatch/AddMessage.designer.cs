﻿namespace TheMatch
{
    partial class AddMessage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTextMessage = new System.Windows.Forms.Label();
            this.labelTypeMessage = new System.Windows.Forms.Label();
            this.textBoxMessage = new System.Windows.Forms.TextBox();
            this.buttonOk = new System.Windows.Forms.Button();
            this.comboBoxTypeMessage = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // labelTextMessage
            // 
            this.labelTextMessage.AutoSize = true;
            this.labelTextMessage.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelTextMessage.Location = new System.Drawing.Point(148, 81);
            this.labelTextMessage.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTextMessage.Name = "labelTextMessage";
            this.labelTextMessage.Size = new System.Drawing.Size(217, 21);
            this.labelTextMessage.TabIndex = 1;
            this.labelTextMessage.Text = "Введите текст сообщения:";
            // 
            // labelTypeMessage
            // 
            this.labelTypeMessage.AutoSize = true;
            this.labelTypeMessage.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelTypeMessage.Location = new System.Drawing.Point(148, 23);
            this.labelTypeMessage.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTypeMessage.Name = "labelTypeMessage";
            this.labelTypeMessage.Size = new System.Drawing.Size(216, 21);
            this.labelTypeMessage.TabIndex = 1;
            this.labelTypeMessage.Text = "Выберите тип сообщения";
            // 
            // textBoxMessage
            // 
            this.textBoxMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxMessage.Location = new System.Drawing.Point(108, 105);
            this.textBoxMessage.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxMessage.MaximumSize = new System.Drawing.Size(0, 90);
            this.textBoxMessage.MaxLength = 3000;
            this.textBoxMessage.MinimumSize = new System.Drawing.Size(300, 90);
            this.textBoxMessage.Name = "textBoxMessage";
            this.textBoxMessage.Size = new System.Drawing.Size(300, 90);
            this.textBoxMessage.TabIndex = 2;
            // 
            // buttonOk
            // 
            this.buttonOk.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonOk.Location = new System.Drawing.Point(206, 275);
            this.buttonOk.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonOk.Name = "buttonOk";
            this.buttonOk.Size = new System.Drawing.Size(94, 32);
            this.buttonOk.TabIndex = 3;
            this.buttonOk.Text = "Отправить";
            this.buttonOk.UseVisualStyleBackColor = true;
            this.buttonOk.Click += new System.EventHandler(this.buttonOk_Click);
            // 
            // comboBoxTypeMessage
            // 
            this.comboBoxTypeMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBoxTypeMessage.FormattingEnabled = true;
            this.comboBoxTypeMessage.Location = new System.Drawing.Point(152, 46);
            this.comboBoxTypeMessage.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxTypeMessage.Name = "comboBoxTypeMessage";
            this.comboBoxTypeMessage.Size = new System.Drawing.Size(206, 23);
            this.comboBoxTypeMessage.TabIndex = 4;
            // 
            // AddMessage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(517, 326);
            this.Controls.Add(this.comboBoxTypeMessage);
            this.Controls.Add(this.buttonOk);
            this.Controls.Add(this.textBoxMessage);
            this.Controls.Add(this.labelTypeMessage);
            this.Controls.Add(this.labelTextMessage);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "AddMessage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Отправить сообщение";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelTextMessage;
        private System.Windows.Forms.Label labelTypeMessage;
        private System.Windows.Forms.TextBox textBoxMessage;
        private System.Windows.Forms.Button buttonOk;
        private System.Windows.Forms.ComboBox comboBoxTypeMessage;
    }
}