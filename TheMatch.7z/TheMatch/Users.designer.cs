﻿namespace TheMatch
{
    partial class Users
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.buttonBackUsers = new System.Windows.Forms.Button();
            this.buttonAddUser = new System.Windows.Forms.Button();
            this.buttonEditUser = new System.Windows.Forms.Button();
            this.buttonDeleteUser = new System.Windows.Forms.Button();
            this.dataGridViewUsers = new System.Windows.Forms.DataGridView();
            this.iDПользователяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.имяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.полDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ростDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датарожденияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.местоположениеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.описаниеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.уровеньзаработкаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.жильёDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.наличиедетейDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.электроннаяпочтаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.парольDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.пользователиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.erimeev_1415_TheMatchDataSet = new TheMatch.Erimeev_1415_TheMatchDataSet();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.пользователиTableAdapter = new TheMatch.Erimeev_1415_TheMatchDataSetTableAdapters.ПользователиTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUsers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erimeev_1415_TheMatchDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonBackUsers
            // 
            this.buttonBackUsers.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.buttonBackUsers.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonBackUsers.ForeColor = System.Drawing.Color.White;
            this.buttonBackUsers.Location = new System.Drawing.Point(34, 406);
            this.buttonBackUsers.Margin = new System.Windows.Forms.Padding(2);
            this.buttonBackUsers.Name = "buttonBackUsers";
            this.buttonBackUsers.Size = new System.Drawing.Size(101, 33);
            this.buttonBackUsers.TabIndex = 0;
            this.buttonBackUsers.Text = "Назад";
            this.buttonBackUsers.UseVisualStyleBackColor = false;
            this.buttonBackUsers.Click += new System.EventHandler(this.buttonBackUser_Click);
            // 
            // buttonAddUser
            // 
            this.buttonAddUser.BackColor = System.Drawing.Color.SeaGreen;
            this.buttonAddUser.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAddUser.ForeColor = System.Drawing.Color.White;
            this.buttonAddUser.Location = new System.Drawing.Point(357, 385);
            this.buttonAddUser.Margin = new System.Windows.Forms.Padding(2);
            this.buttonAddUser.Name = "buttonAddUser";
            this.buttonAddUser.Size = new System.Drawing.Size(136, 54);
            this.buttonAddUser.TabIndex = 1;
            this.buttonAddUser.Text = "Добавить";
            this.buttonAddUser.UseVisualStyleBackColor = false;
            this.buttonAddUser.Click += new System.EventHandler(this.buttonAddUser_Click);
            // 
            // buttonEditUser
            // 
            this.buttonEditUser.BackColor = System.Drawing.Color.SeaGreen;
            this.buttonEditUser.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonEditUser.ForeColor = System.Drawing.Color.White;
            this.buttonEditUser.Location = new System.Drawing.Point(173, 385);
            this.buttonEditUser.Margin = new System.Windows.Forms.Padding(2);
            this.buttonEditUser.Name = "buttonEditUser";
            this.buttonEditUser.Size = new System.Drawing.Size(136, 54);
            this.buttonEditUser.TabIndex = 2;
            this.buttonEditUser.Text = "Изменить";
            this.buttonEditUser.UseVisualStyleBackColor = false;
            this.buttonEditUser.Click += new System.EventHandler(this.buttonEditUser_Click);
            // 
            // buttonDeleteUser
            // 
            this.buttonDeleteUser.BackColor = System.Drawing.Color.SeaGreen;
            this.buttonDeleteUser.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonDeleteUser.ForeColor = System.Drawing.Color.White;
            this.buttonDeleteUser.Location = new System.Drawing.Point(544, 385);
            this.buttonDeleteUser.Margin = new System.Windows.Forms.Padding(2);
            this.buttonDeleteUser.Name = "buttonDeleteUser";
            this.buttonDeleteUser.Size = new System.Drawing.Size(136, 54);
            this.buttonDeleteUser.TabIndex = 3;
            this.buttonDeleteUser.Text = "Удалить";
            this.buttonDeleteUser.UseVisualStyleBackColor = false;
            this.buttonDeleteUser.Click += new System.EventHandler(this.buttonDeleteUser_Click);
            // 
            // dataGridViewUsers
            // 
            this.dataGridViewUsers.AutoGenerateColumns = false;
            this.dataGridViewUsers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewUsers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDПользователяDataGridViewTextBoxColumn,
            this.имяDataGridViewTextBoxColumn,
            this.полDataGridViewTextBoxColumn,
            this.ростDataGridViewTextBoxColumn,
            this.датарожденияDataGridViewTextBoxColumn,
            this.местоположениеDataGridViewTextBoxColumn,
            this.описаниеDataGridViewTextBoxColumn,
            this.уровеньзаработкаDataGridViewTextBoxColumn,
            this.жильёDataGridViewTextBoxColumn,
            this.наличиедетейDataGridViewCheckBoxColumn,
            this.электроннаяпочтаDataGridViewTextBoxColumn,
            this.парольDataGridViewTextBoxColumn});
            this.dataGridViewUsers.DataSource = this.пользователиBindingSource;
            this.dataGridViewUsers.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridViewUsers.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewUsers.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewUsers.Name = "dataGridViewUsers";
            this.dataGridViewUsers.RowHeadersWidth = 51;
            this.dataGridViewUsers.RowTemplate.Height = 24;
            this.dataGridViewUsers.Size = new System.Drawing.Size(862, 369);
            this.dataGridViewUsers.TabIndex = 4;
            // 
            // iDПользователяDataGridViewTextBoxColumn
            // 
            this.iDПользователяDataGridViewTextBoxColumn.DataPropertyName = "ID_Пользователя";
            this.iDПользователяDataGridViewTextBoxColumn.HeaderText = "ID_Пользователя";
            this.iDПользователяDataGridViewTextBoxColumn.Name = "iDПользователяDataGridViewTextBoxColumn";
            this.iDПользователяDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // имяDataGridViewTextBoxColumn
            // 
            this.имяDataGridViewTextBoxColumn.DataPropertyName = "Имя";
            this.имяDataGridViewTextBoxColumn.HeaderText = "Имя";
            this.имяDataGridViewTextBoxColumn.Name = "имяDataGridViewTextBoxColumn";
            // 
            // полDataGridViewTextBoxColumn
            // 
            this.полDataGridViewTextBoxColumn.DataPropertyName = "Пол";
            this.полDataGridViewTextBoxColumn.HeaderText = "Пол";
            this.полDataGridViewTextBoxColumn.Name = "полDataGridViewTextBoxColumn";
            // 
            // ростDataGridViewTextBoxColumn
            // 
            this.ростDataGridViewTextBoxColumn.DataPropertyName = "Рост";
            this.ростDataGridViewTextBoxColumn.HeaderText = "Рост";
            this.ростDataGridViewTextBoxColumn.Name = "ростDataGridViewTextBoxColumn";
            // 
            // датарожденияDataGridViewTextBoxColumn
            // 
            this.датарожденияDataGridViewTextBoxColumn.DataPropertyName = "Дата_рождения";
            this.датарожденияDataGridViewTextBoxColumn.HeaderText = "Дата_рождения";
            this.датарожденияDataGridViewTextBoxColumn.Name = "датарожденияDataGridViewTextBoxColumn";
            // 
            // местоположениеDataGridViewTextBoxColumn
            // 
            this.местоположениеDataGridViewTextBoxColumn.DataPropertyName = "Местоположение";
            this.местоположениеDataGridViewTextBoxColumn.HeaderText = "Местоположение";
            this.местоположениеDataGridViewTextBoxColumn.Name = "местоположениеDataGridViewTextBoxColumn";
            // 
            // описаниеDataGridViewTextBoxColumn
            // 
            this.описаниеDataGridViewTextBoxColumn.DataPropertyName = "Описание";
            this.описаниеDataGridViewTextBoxColumn.HeaderText = "Описание";
            this.описаниеDataGridViewTextBoxColumn.Name = "описаниеDataGridViewTextBoxColumn";
            // 
            // уровеньзаработкаDataGridViewTextBoxColumn
            // 
            this.уровеньзаработкаDataGridViewTextBoxColumn.DataPropertyName = "Уровень_заработка";
            this.уровеньзаработкаDataGridViewTextBoxColumn.HeaderText = "Уровень_заработка";
            this.уровеньзаработкаDataGridViewTextBoxColumn.Name = "уровеньзаработкаDataGridViewTextBoxColumn";
            // 
            // жильёDataGridViewTextBoxColumn
            // 
            this.жильёDataGridViewTextBoxColumn.DataPropertyName = "Жильё";
            this.жильёDataGridViewTextBoxColumn.HeaderText = "Жильё";
            this.жильёDataGridViewTextBoxColumn.Name = "жильёDataGridViewTextBoxColumn";
            // 
            // наличиедетейDataGridViewCheckBoxColumn
            // 
            this.наличиедетейDataGridViewCheckBoxColumn.DataPropertyName = "Наличие_детей";
            this.наличиедетейDataGridViewCheckBoxColumn.HeaderText = "Наличие_детей";
            this.наличиедетейDataGridViewCheckBoxColumn.Name = "наличиедетейDataGridViewCheckBoxColumn";
            // 
            // электроннаяпочтаDataGridViewTextBoxColumn
            // 
            this.электроннаяпочтаDataGridViewTextBoxColumn.DataPropertyName = "Электронная_почта";
            this.электроннаяпочтаDataGridViewTextBoxColumn.HeaderText = "Электронная_почта";
            this.электроннаяпочтаDataGridViewTextBoxColumn.Name = "электроннаяпочтаDataGridViewTextBoxColumn";
            // 
            // парольDataGridViewTextBoxColumn
            // 
            this.парольDataGridViewTextBoxColumn.DataPropertyName = "Пароль";
            this.парольDataGridViewTextBoxColumn.HeaderText = "Пароль";
            this.парольDataGridViewTextBoxColumn.Name = "парольDataGridViewTextBoxColumn";
            // 
            // пользователиBindingSource
            // 
            this.пользователиBindingSource.DataMember = "Пользователи";
            this.пользователиBindingSource.DataSource = this.erimeev_1415_TheMatchDataSet;
            // 
            // erimeev_1415_TheMatchDataSet
            // 
            this.erimeev_1415_TheMatchDataSet.DataSetName = "Erimeev_1415_TheMatchDataSet";
            this.erimeev_1415_TheMatchDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.BackColor = System.Drawing.Color.White;
            this.buttonUpdate.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonUpdate.ForeColor = System.Drawing.Color.SeaGreen;
            this.buttonUpdate.Location = new System.Drawing.Point(740, 405);
            this.buttonUpdate.Margin = new System.Windows.Forms.Padding(2);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(101, 33);
            this.buttonUpdate.TabIndex = 5;
            this.buttonUpdate.Text = "Обновить";
            this.buttonUpdate.UseVisualStyleBackColor = false;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // пользователиTableAdapter
            // 
            this.пользователиTableAdapter.ClearBeforeFill = true;
            // 
            // Users
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(862, 449);
            this.Controls.Add(this.buttonUpdate);
            this.Controls.Add(this.dataGridViewUsers);
            this.Controls.Add(this.buttonDeleteUser);
            this.Controls.Add(this.buttonEditUser);
            this.Controls.Add(this.buttonAddUser);
            this.Controls.Add(this.buttonBackUsers);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Users";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Данные пользователей";
            this.Load += new System.EventHandler(this.Users_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUsers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erimeev_1415_TheMatchDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonBackUsers;
        private System.Windows.Forms.Button buttonAddUser;
        private System.Windows.Forms.Button buttonEditUser;
        private System.Windows.Forms.Button buttonDeleteUser;
        private System.Windows.Forms.DataGridView dataGridViewUsers;
        private System.Windows.Forms.Button buttonUpdate;
        private TheMatch.Erimeev_1415_TheMatchDataSet erimeev_1415_TheMatchDataSet;
        private System.Windows.Forms.BindingSource пользователиBindingSource;
        private TheMatch.Erimeev_1415_TheMatchDataSetTableAdapters.ПользователиTableAdapter пользователиTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDПользователяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn имяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn полDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ростDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датарожденияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn местоположениеDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn описаниеDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn уровеньзаработкаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn жильёDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn наличиедетейDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn электроннаяпочтаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn парольDataGridViewTextBoxColumn;
    }
}