﻿namespace TheMatch
{
    partial class Message
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.buttonBackMessage = new System.Windows.Forms.Button();
            this.buttonAddMessage = new System.Windows.Forms.Button();
            this.buttonDeleteMessage = new System.Windows.Forms.Button();
            this.dataGridViewMessage = new System.Windows.Forms.DataGridView();
            this.просмотрСообщенийПользователейBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.erimeev_1415_TheMatchDataSet = new TheMatch.Erimeev_1415_TheMatchDataSet();
            this.просмотр_Сообщений_ПользователейTableAdapter = new TheMatch.Erimeev_1415_TheMatchDataSetTableAdapters.Просмотр_Сообщений_ПользователейTableAdapter();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.iDСообщенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDПользователяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типсообщенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.текстсообщенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаивремяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMessage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.просмотрСообщенийПользователейBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erimeev_1415_TheMatchDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonBackMessage
            // 
            this.buttonBackMessage.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.buttonBackMessage.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonBackMessage.ForeColor = System.Drawing.Color.White;
            this.buttonBackMessage.Location = new System.Drawing.Point(21, 396);
            this.buttonBackMessage.Margin = new System.Windows.Forms.Padding(2);
            this.buttonBackMessage.Name = "buttonBackMessage";
            this.buttonBackMessage.Size = new System.Drawing.Size(101, 33);
            this.buttonBackMessage.TabIndex = 0;
            this.buttonBackMessage.Text = "Назад";
            this.buttonBackMessage.UseVisualStyleBackColor = false;
            this.buttonBackMessage.Click += new System.EventHandler(this.buttonBackMessage_Click);
            // 
            // buttonAddMessage
            // 
            this.buttonAddMessage.BackColor = System.Drawing.Color.LightCoral;
            this.buttonAddMessage.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAddMessage.ForeColor = System.Drawing.Color.White;
            this.buttonAddMessage.Location = new System.Drawing.Point(226, 384);
            this.buttonAddMessage.Margin = new System.Windows.Forms.Padding(2);
            this.buttonAddMessage.Name = "buttonAddMessage";
            this.buttonAddMessage.Size = new System.Drawing.Size(136, 54);
            this.buttonAddMessage.TabIndex = 1;
            this.buttonAddMessage.Text = "Отправить сообщение";
            this.buttonAddMessage.UseVisualStyleBackColor = false;
            this.buttonAddMessage.Click += new System.EventHandler(this.buttonAddMessage_Click);
            // 
            // buttonDeleteMessage
            // 
            this.buttonDeleteMessage.BackColor = System.Drawing.Color.LightCoral;
            this.buttonDeleteMessage.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonDeleteMessage.ForeColor = System.Drawing.Color.White;
            this.buttonDeleteMessage.Location = new System.Drawing.Point(482, 385);
            this.buttonDeleteMessage.Margin = new System.Windows.Forms.Padding(2);
            this.buttonDeleteMessage.Name = "buttonDeleteMessage";
            this.buttonDeleteMessage.Size = new System.Drawing.Size(136, 53);
            this.buttonDeleteMessage.TabIndex = 3;
            this.buttonDeleteMessage.Text = "Удалить своё сообщение";
            this.buttonDeleteMessage.UseVisualStyleBackColor = false;
            this.buttonDeleteMessage.Click += new System.EventHandler(this.buttonDeleteMessage_Click);
            // 
            // dataGridViewMessage
            // 
            this.dataGridViewMessage.AutoGenerateColumns = false;
            this.dataGridViewMessage.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewMessage.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMessage.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDСообщенияDataGridViewTextBoxColumn,
            this.iDПользователяDataGridViewTextBoxColumn,
            this.типсообщенияDataGridViewTextBoxColumn,
            this.текстсообщенияDataGridViewTextBoxColumn,
            this.датаивремяDataGridViewTextBoxColumn});
            this.dataGridViewMessage.DataSource = this.просмотрСообщенийПользователейBindingSource;
            this.dataGridViewMessage.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridViewMessage.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewMessage.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewMessage.Name = "dataGridViewMessage";
            this.dataGridViewMessage.RowHeadersWidth = 51;
            this.dataGridViewMessage.RowTemplate.Height = 24;
            this.dataGridViewMessage.Size = new System.Drawing.Size(862, 369);
            this.dataGridViewMessage.TabIndex = 4;
            // 
            // просмотрСообщенийПользователейBindingSource
            // 
            this.просмотрСообщенийПользователейBindingSource.DataMember = "Просмотр_Сообщений_Пользователей";
            this.просмотрСообщенийПользователейBindingSource.DataSource = this.erimeev_1415_TheMatchDataSet;
            // 
            // erimeev_1415_TheMatchDataSet
            // 
            this.erimeev_1415_TheMatchDataSet.DataSetName = "Erimeev_1415_TheMatchDataSet";
            this.erimeev_1415_TheMatchDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // просмотр_Сообщений_ПользователейTableAdapter
            // 
            this.просмотр_Сообщений_ПользователейTableAdapter.ClearBeforeFill = true;
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.BackColor = System.Drawing.SystemColors.Window;
            this.buttonUpdate.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonUpdate.ForeColor = System.Drawing.Color.LightCoral;
            this.buttonUpdate.Location = new System.Drawing.Point(743, 396);
            this.buttonUpdate.Margin = new System.Windows.Forms.Padding(2);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(101, 33);
            this.buttonUpdate.TabIndex = 5;
            this.buttonUpdate.Text = "Обновить";
            this.buttonUpdate.UseVisualStyleBackColor = false;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click_1);
            // 
            // iDСообщенияDataGridViewTextBoxColumn
            // 
            this.iDСообщенияDataGridViewTextBoxColumn.DataPropertyName = "ID_Сообщения";
            this.iDСообщенияDataGridViewTextBoxColumn.HeaderText = "ID_Сообщения";
            this.iDСообщенияDataGridViewTextBoxColumn.Name = "iDСообщенияDataGridViewTextBoxColumn";
            // 
            // iDПользователяDataGridViewTextBoxColumn
            // 
            this.iDПользователяDataGridViewTextBoxColumn.DataPropertyName = "ID_Пользователя";
            this.iDПользователяDataGridViewTextBoxColumn.HeaderText = "ID_Пользователя";
            this.iDПользователяDataGridViewTextBoxColumn.Name = "iDПользователяDataGridViewTextBoxColumn";
            // 
            // типсообщенияDataGridViewTextBoxColumn
            // 
            this.типсообщенияDataGridViewTextBoxColumn.DataPropertyName = "Тип_сообщения";
            this.типсообщенияDataGridViewTextBoxColumn.HeaderText = "Тип_сообщения";
            this.типсообщенияDataGridViewTextBoxColumn.Name = "типсообщенияDataGridViewTextBoxColumn";
            // 
            // текстсообщенияDataGridViewTextBoxColumn
            // 
            this.текстсообщенияDataGridViewTextBoxColumn.DataPropertyName = "Текст_сообщения";
            this.текстсообщенияDataGridViewTextBoxColumn.HeaderText = "Текст_сообщения";
            this.текстсообщенияDataGridViewTextBoxColumn.Name = "текстсообщенияDataGridViewTextBoxColumn";
            // 
            // датаивремяDataGridViewTextBoxColumn
            // 
            this.датаивремяDataGridViewTextBoxColumn.DataPropertyName = "Дата_и_время";
            this.датаивремяDataGridViewTextBoxColumn.HeaderText = "Дата_и_время";
            this.датаивремяDataGridViewTextBoxColumn.Name = "датаивремяDataGridViewTextBoxColumn";
            // 
            // Message
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(862, 449);
            this.Controls.Add(this.buttonUpdate);
            this.Controls.Add(this.dataGridViewMessage);
            this.Controls.Add(this.buttonDeleteMessage);
            this.Controls.Add(this.buttonAddMessage);
            this.Controls.Add(this.buttonBackMessage);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Message";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Сообщения пользователей";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMessage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.просмотрСообщенийПользователейBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erimeev_1415_TheMatchDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonBackMessage;
        private System.Windows.Forms.Button buttonAddMessage;
        private System.Windows.Forms.Button buttonDeleteMessage;
        private System.Windows.Forms.DataGridView dataGridViewMessage;
        private Erimeev_1415_TheMatchDataSet erimeev_1415_TheMatchDataSet;
        private System.Windows.Forms.BindingSource просмотрСообщенийПользователейBindingSource;
        private Erimeev_1415_TheMatchDataSetTableAdapters.Просмотр_Сообщений_ПользователейTableAdapter просмотр_Сообщений_ПользователейTableAdapter;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDСообщенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDПользователяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn типсообщенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn текстсообщенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаивремяDataGridViewTextBoxColumn;
    }
}