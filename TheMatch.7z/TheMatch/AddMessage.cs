﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TheMatch
{
    public partial class AddMessage : Form
    {
        private string connectionString = "Server = DESKTOP-E7PFLIN\\SQLEXPRESS;" +
                                   "Initial Catalog = Erimeev_1415_TheMatch;" +
                                   "Integrated Security = True;";

        public AddMessage()
        {
            InitializeComponent();
            AddComboBoxTypeMessage();
        }

        private void buttonOk_Click(object sender, EventArgs e)
        {
            try
            {
                // Получение ID пользователя по Email
                int userID = GetUserIDByEmail(CurrentUser.Email);

                // Проверка, получен ли ID пользователя
                if (userID > 0)
                {
                    // Получение ID выбранного типа сообщения
                    int typeID = GetMessageTypeIDByName(comboBoxTypeMessage.SelectedItem.ToString());

                    // Вызов хранимой процедуры для добавления сообщения
                    AddUserMessage(userID, textBoxMessage.Text, typeID);

                    MessageBox.Show("Сообщение отправлено!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Ошибка: Не удалось получить ID пользователя.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка! " + ex.Message);
            }
        }

        private void AddComboBoxTypeMessage()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT Название_типа FROM Тип_сообщения";

                conn.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        comboBoxTypeMessage.Items.Add(reader["Название_типа"].ToString());
                    }
                }

                conn.Close();
            }
        }

        private int GetUserIDByEmail(string email)
        {
            int userID = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT ID_Пользователя FROM Пользователи WHERE Электронная_почта = @Email";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Email", email);
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            userID = Convert.ToInt32(reader["ID_Пользователя"]);
                        }
                    }
                }
            }
            return userID;
        }

        private int GetMessageTypeIDByName(string typeName)
        {
            int typeID = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT ID_Типа_сообщения FROM Тип_сообщения WHERE Название_типа = @TypeName";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@TypeName", typeName);
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            typeID = Convert.ToInt32(reader["ID_Типа_сообщения"]);
                        }
                    }
                }
            }
            return typeID;
        }

        private void AddUserMessage(int userID, string messageText, int typeID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand("AddMessageUser", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@ID_Пользователя", userID);
                    command.Parameters.AddWithValue("@Текст_сообщения", messageText);
                    command.Parameters.AddWithValue("@ID_Типа_сообщения", typeID);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
