﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TheMatch
{
    public partial class Activities : Form
    {
        private string connectionString = "Server = DESKTOP-E7PFLIN\\SQLEXPRESS;" +
                                   "Initial Catalog = Erimeev_1415_TheMatch;" +
                                   "Integrated Security = True;";
        public Activities()
        {
            InitializeComponent();
        }

        private void buttonBackUserActivity_Click(object sender, EventArgs e)
        {
            MenuUser menuUser = new MenuUser();
            menuUser.Show();
            this.Hide();
        }

        private void LoadUserInteractions()
        {

            // Получаем ID текущего пользователя по email
            string email = CurrentUser.Email;
            if (string.IsNullOrEmpty(email))
            {
                MessageBox.Show("Email текущего пользователя не указан.");
                return;
            }

            int userID = GetUserIDByEmail(email);

            if (userID > 0)
            {
                DataTable dataTable = new DataTable();

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        using (SqlCommand command = new SqlCommand("GetInteractions", connection))
                        {
                            command.CommandType = CommandType.StoredProcedure;
                            command.Parameters.AddWithValue("@ID_Пользователя", userID);

                            connection.Open();

                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                if (reader.HasRows)
                                {
                                    dataTable.Load(reader);
                                }
                                else
                                {
                                    MessageBox.Show("Нет данных для отображения.");
                                }
                            }
                        }

                        // Проверка, есть ли данные в DataTable
                        if (dataTable.Rows.Count > 0)
                        {
                            // Привязываем DataTable к DataGridView
                            dataGridViewUserActivity.DataSource = dataTable;
                        }
                        else
                        {
                            MessageBox.Show("Получена пустая таблица.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при выполнении запроса: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Не удалось получить ID пользователя по email.");
            }
        }

        private int GetUserIDByEmail(string email)
        {
            int userID = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    string query = "SELECT ID_Пользователя FROM Пользователи WHERE Электронная_почта = @Email";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Email", email);
                        connection.Open();

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                userID = Convert.ToInt32(reader["ID_Пользователя"]);
                            }
                            else
                            {
                                MessageBox.Show("Пользователь с указанным email не найден.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при получении ID пользователя: " + ex.Message);
                }
            }
            return userID;
        }

        private void Activities_Load(object sender, EventArgs e)
        {
            LoadUserInteractions();
        }


        private void buttonUpdateUserActivity_Click(object sender, EventArgs e)
        {

            LoadUserInteractions();
        }
    }
}
