﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;
using TheMatch;

namespace TheMatch
{
    public partial class ModeratorInter : Form
    {
        // Строка подключения к базе данных 
        private string connectionString = "Server = DESKTOP-E7PFLIN\\SQLEXPRESS;" +
                                   "Initial Catalog = Erimeev_1415_TheMatch;" +
                                   "Integrated Security = True;";

        public ModeratorInter()
        {
            InitializeComponent();
        }

        private void buttonInter_Click(object sender, EventArgs e)
        {
            string login = textBoxLogin.Text;
            string password = textBoxParol.Text;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Пароль, Электронная_почта FROM Модератор WHERE Электронная_почта = @Login";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Login", login);
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            reader.Read();
                            string storedPassword = reader.GetString(0); // Пароль - первый столбец

                            if (storedPassword == password)
                            {
                                CurrentUser.Email = reader.GetString(1); // Электронная почта - второй столбец
                                MenuModerator menuModerator = new MenuModerator();
                                menuModerator.Show();
                                this.Hide();
                            }
                            else
                            {
                                MessageBox.Show("Неправильный пароль", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Логин не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            textBoxParol.Text = "";
        }

        private void buttonBack1_Click(object sender, EventArgs e)
        {
            StartPage startpage = new StartPage();
            startpage.Show();
            this.Hide();
        }
    }
}
