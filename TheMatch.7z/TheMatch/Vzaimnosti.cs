﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TheMatch
{
    public partial class Vzaimnosti : Form
    {
        private string connectionString = "Server = DESKTOP-E7PFLIN\\SQLEXPRESS;" +
                                   "Initial Catalog = Erimeev_1415_TheMatch;" +
                                   "Integrated Security = True;";
        public Vzaimnosti()
        {
            InitializeComponent();
        }

        private void buttonBackVzaimki_Click(object sender, EventArgs e)
        {
            MenuUser menuUser = new MenuUser();
            menuUser.Show();
            this.Hide();
        }

        private void LoadReciprocityData()
        {
            // Получаем ID текущего пользователя по email
            int userID = GetUserIDByEmail(CurrentUser.Email);

            if (userID > 0)
            {
                listBoxUserVzaimnosti.Items.Clear();

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand("ShowReciprocity", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@ID_Пользователя", userID);

                        connection.Open();

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int reciprocalUserID = Convert.ToInt32(reader["ID_Взаимного_Пользователя"]);

                                // Получаем имя и возраст взаимного пользователя
                                string reciprocalUserName = GetUserNameByID(reciprocalUserID);
                                int reciprocalUserAge = GetUserAgeByID(reciprocalUserID);

                                // Формируем строку для отображения в listBoxUserVzaimnosti
                                string listItem = "ID Пользователя " + $"{reciprocalUserID} - {reciprocalUserName} ({reciprocalUserAge} лет)";

                                // Добавляем строку в ListBox
                                listBoxUserVzaimnosti.Items.Add(listItem);
                            }
                        }
                    }
                }
            }
        }


        private int GetUserIDByEmail(string email)
        {
            int userID = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT ID_Пользователя FROM Пользователи WHERE Электронная_почта = @Email";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Email", email);
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            userID = Convert.ToInt32(reader["ID_Пользователя"]);
                        }
                    }
                }
            }
            return userID;
        }

        private string GetUserNameByID(int userID)
        {
            string userName = "";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Имя FROM Пользователи WHERE ID_Пользователя = @UserID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);
                    connection.Open();
                    userName = command.ExecuteScalar()?.ToString();
                }
            }
            return userName;
        }

        private int GetUserAgeByID(int userID)
        {
            int userAge = 0;
  
             DateTime birthDate = GetBirthDateByID(userID);
             userAge = CalculateAge(birthDate);
    
            return userAge;
        }

        private DateTime GetBirthDateByID(int userID)
        {
            DateTime birthDate = DateTime.MinValue;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Дата_рождения FROM Пользователи WHERE ID_Пользователя = @UserID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);
                    connection.Open();
                    birthDate = Convert.ToDateTime(command.ExecuteScalar());
                }
            }
            return birthDate;
        }

        // Метод CalculateAge для расчета возраста пользователя
        private int CalculateAge(DateTime birthDate)
        {
            DateTime now = DateTime.Today;
            int age = now.Year - birthDate.Year;
            if (birthDate > now.AddYears(-age)) age--;
            return age;
        }

        private void Vzaimnosti_Load(object sender, EventArgs e)
        {
            LoadReciprocityData();
        }

        private void buttonUpdateVzaimki_Click(object sender, EventArgs e)
        {
            // Вызываем метод для загрузки новых данных о взаимностях
            LoadReciprocityData();
        }

    }
}
