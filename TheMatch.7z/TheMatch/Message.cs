﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TheMatch
{
    public partial class Message : Form
    {
        private static string connectionString = "Server = DESKTOP-E7PFLIN\\SQLEXPRESS;" +
                                   "Initial Catalog = Erimeev_1415_TheMatch;" +
                                   "Integrated Security = True;";
        private SqlConnection connection = new SqlConnection(connectionString);

        public Message()
        {
            InitializeComponent();
            LoadData();
        }

        private void buttonBackMessage_Click(object sender, EventArgs e)
        {
            MenuUser menuuser = new MenuUser();
            menuuser.Show();
            this.Hide();
        }

        private void LoadData()
        {
            SqlDataAdapter adapterProduction = new SqlDataAdapter("SELECT * FROM Просмотр_Сообщений_Пользователей", connection);
            DataTable tableProduction = new DataTable();
            adapterProduction.Fill(tableProduction);
            dataGridViewMessage.DataSource = tableProduction;
        }

        private void buttonAddMessage_Click(object sender, EventArgs e)
        {
            AddMessage addmessage = new AddMessage();
            addmessage.Show();
        }

        private void buttonDeleteMessage_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridViewMessage.SelectedRows.Count > 0)
                {
                    // Получение выбранной строки
                    DataGridViewRow selectedRow = dataGridViewMessage.SelectedRows[0];

                    // Получение нужных значений из выбранной строки
                    int messageID = Convert.ToInt32(selectedRow.Cells["iDСообщенияDataGridViewTextBoxColumn"].Value);
                    int userID = GetUserIDByEmail(CurrentUser.Email);


                    // Запрос подтверждения перед удалением
                    DialogResult result = MessageBox.Show($"Вы уверены, что хотите удалить это сообщение?", "Подтверждение удаления", MessageBoxButtons.YesNo);

                    if (result == DialogResult.Yes)
                    {
                        using (SqlConnection conn = new SqlConnection(connectionString))
                        {
                            conn.Open();

                            using (SqlCommand cmd = new SqlCommand("DeleteMessageUser", conn))
                            {
                                cmd.CommandType = CommandType.StoredProcedure;

                                cmd.Parameters.AddWithValue("@ID_Пользователя", userID);
                                cmd.Parameters.AddWithValue("@ID_Сообщения", messageID);

                                // Выполнение хранимой процедуры
                                int success = Convert.ToInt32(cmd.ExecuteScalar());

                                if (success == 1)
                                {
                                    MessageBox.Show("Сообщение успешно удалено");
                                    UpdateDataGridView();
                                }
                                else
                                {
                                    MessageBox.Show("Ошибка при удалении сообщения");
                                }
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Выберите строку для удаления");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Произошла ошибка: " + ex.Message);
            }
        }

        private int GetUserIDByEmail(string email)
        {
            int userID = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT ID_Пользователя FROM Пользователи WHERE Электронная_почта = @Email";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Email", email);
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            userID = Convert.ToInt32(reader["ID_Пользователя"]);
                        }
                    }
                }
            }
            return userID;
        }

        private void UpdateDataGridView()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string query = "SELECT * FROM Просмотр_Сообщений_Пользователей";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dataGridViewMessage.DataSource = dataTable;
                }
            }
        }

        private void buttonUpdate_Click_1(object sender, EventArgs e)
        {
            UpdateDataGridView();
        }
    }
}
