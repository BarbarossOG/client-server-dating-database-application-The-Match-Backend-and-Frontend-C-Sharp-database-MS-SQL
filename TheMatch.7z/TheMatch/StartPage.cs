﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheMatch
{
    public partial class StartPage : Form
    {
        public StartPage()
        {
            InitializeComponent();
            //Application.ApplicationExit += Application_ApplicationExit;
        }

        private void buttonModerator_Click(object sender, EventArgs e)
        {
            ModeratorInter moderatorinter = new ModeratorInter();
            moderatorinter.Show();
            this.Hide();
        }

        private void buttonUser_Click(object sender, EventArgs e)
        {
            UserInter userinter = new UserInter();
            userinter.Show();
            this.Hide();
        }

        // Обработчик события ApplicationExit
        private void StartPage_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void StartPage_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = false;
            }
        }
    }
}
