﻿namespace TheMatch
{
    partial class Otchet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.buttonBackModerator = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.erimeev_1415_TheMatchDataSet = new TheMatch.Erimeev_1415_TheMatchDataSet();
            this.принятыепредложенияBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.принятые_предложенияTableAdapter = new TheMatch.Erimeev_1415_TheMatchDataSetTableAdapters.Принятые_предложенияTableAdapter();
            this.предложениепоулучшениюDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.неактивныеПользователиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.неактивныеПользователиTableAdapter = new TheMatch.Erimeev_1415_TheMatchDataSetTableAdapters.НеактивныеПользователиTableAdapter();
            this.iDПользователяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.имяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.последнеевзаимодействиеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erimeev_1415_TheMatchDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.принятыепредложенияBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.неактивныеПользователиBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonBackModerator
            // 
            this.buttonBackModerator.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.buttonBackModerator.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonBackModerator.ForeColor = System.Drawing.Color.White;
            this.buttonBackModerator.Location = new System.Drawing.Point(335, 389);
            this.buttonBackModerator.Margin = new System.Windows.Forms.Padding(2);
            this.buttonBackModerator.Name = "buttonBackModerator";
            this.buttonBackModerator.Size = new System.Drawing.Size(112, 38);
            this.buttonBackModerator.TabIndex = 4;
            this.buttonBackModerator.Text = "Назад";
            this.buttonBackModerator.UseVisualStyleBackColor = false;
            this.buttonBackModerator.Click += new System.EventHandler(this.buttonBackModerator_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(5, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(783, 381);
            this.tabControl1.TabIndex = 5;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(775, 355);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "ПредложенияПоУлучшению";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(775, 355);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "НеактивныеЮзеры";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.предложениепоулучшениюDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.принятыепредложенияBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(6, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(422, 352);
            this.dataGridView1.TabIndex = 0;
            // 
            // erimeev_1415_TheMatchDataSet
            // 
            this.erimeev_1415_TheMatchDataSet.DataSetName = "Erimeev_1415_TheMatchDataSet";
            this.erimeev_1415_TheMatchDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // принятыепредложенияBindingSource
            // 
            this.принятыепредложенияBindingSource.DataMember = "Принятые_предложения";
            this.принятыепредложенияBindingSource.DataSource = this.erimeev_1415_TheMatchDataSet;
            // 
            // принятые_предложенияTableAdapter
            // 
            this.принятые_предложенияTableAdapter.ClearBeforeFill = true;
            // 
            // предложениепоулучшениюDataGridViewTextBoxColumn
            // 
            this.предложениепоулучшениюDataGridViewTextBoxColumn.DataPropertyName = "Предложение_по_улучшению";
            this.предложениепоулучшениюDataGridViewTextBoxColumn.HeaderText = "Предложение_по_улучшению";
            this.предложениепоулучшениюDataGridViewTextBoxColumn.Name = "предложениепоулучшениюDataGridViewTextBoxColumn";
            this.предложениепоулучшениюDataGridViewTextBoxColumn.Width = 400;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDПользователяDataGridViewTextBoxColumn,
            this.имяDataGridViewTextBoxColumn,
            this.последнеевзаимодействиеDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.неактивныеПользователиBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(3, 3);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(435, 346);
            this.dataGridView2.TabIndex = 0;
            // 
            // неактивныеПользователиBindingSource
            // 
            this.неактивныеПользователиBindingSource.DataMember = "НеактивныеПользователи";
            this.неактивныеПользователиBindingSource.DataSource = this.erimeev_1415_TheMatchDataSet;
            // 
            // неактивныеПользователиTableAdapter
            // 
            this.неактивныеПользователиTableAdapter.ClearBeforeFill = true;
            // 
            // iDПользователяDataGridViewTextBoxColumn
            // 
            this.iDПользователяDataGridViewTextBoxColumn.DataPropertyName = "ID_Пользователя";
            this.iDПользователяDataGridViewTextBoxColumn.HeaderText = "ID_Пользователя";
            this.iDПользователяDataGridViewTextBoxColumn.Name = "iDПользователяDataGridViewTextBoxColumn";
            this.iDПользователяDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // имяDataGridViewTextBoxColumn
            // 
            this.имяDataGridViewTextBoxColumn.DataPropertyName = "Имя";
            this.имяDataGridViewTextBoxColumn.HeaderText = "Имя";
            this.имяDataGridViewTextBoxColumn.Name = "имяDataGridViewTextBoxColumn";
            this.имяDataGridViewTextBoxColumn.Width = 150;
            // 
            // последнеевзаимодействиеDataGridViewTextBoxColumn
            // 
            this.последнеевзаимодействиеDataGridViewTextBoxColumn.DataPropertyName = "Последнее_взаимодействие";
            this.последнеевзаимодействиеDataGridViewTextBoxColumn.HeaderText = "Последнее_взаимодействие";
            this.последнеевзаимодействиеDataGridViewTextBoxColumn.Name = "последнеевзаимодействиеDataGridViewTextBoxColumn";
            this.последнеевзаимодействиеDataGridViewTextBoxColumn.ReadOnly = true;
            this.последнеевзаимодействиеDataGridViewTextBoxColumn.Width = 150;
            // 
            // Otchet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.buttonBackModerator);
            this.Name = "Otchet";
            this.Text = "Отчёты";
            this.Load += new System.EventHandler(this.Otchet_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erimeev_1415_TheMatchDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.принятыепредложенияBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.неактивныеПользователиBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonBackModerator;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tabPage2;
        private Erimeev_1415_TheMatchDataSet erimeev_1415_TheMatchDataSet;
        private System.Windows.Forms.BindingSource принятыепредложенияBindingSource;
        private Erimeev_1415_TheMatchDataSetTableAdapters.Принятые_предложенияTableAdapter принятые_предложенияTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn предложениепоулучшениюDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.BindingSource неактивныеПользователиBindingSource;
        private Erimeev_1415_TheMatchDataSetTableAdapters.НеактивныеПользователиTableAdapter неактивныеПользователиTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDПользователяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn имяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn последнеевзаимодействиеDataGridViewTextBoxColumn;
    }
}