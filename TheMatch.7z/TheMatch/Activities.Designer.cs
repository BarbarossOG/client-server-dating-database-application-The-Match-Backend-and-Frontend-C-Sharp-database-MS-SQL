﻿namespace TheMatch
{
    partial class Activities
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.buttonUpdateUserActivity = new System.Windows.Forms.Button();
            this.labelInfo = new System.Windows.Forms.Label();
            this.buttonBackUserActivity = new System.Windows.Forms.Button();
            this.dataGridViewUserActivity = new System.Windows.Forms.DataGridView();
            this.erimeev_1415_TheMatchDataSet = new TheMatch.Erimeev_1415_TheMatchDataSet();
            this.getInteractionsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.getInteractionsTableAdapter = new TheMatch.Erimeev_1415_TheMatchDataSetTableAdapters.GetInteractionsTableAdapter();
            this.имяпользователяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типвзаимодействияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаивремяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUserActivity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erimeev_1415_TheMatchDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.getInteractionsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonUpdateUserActivity
            // 
            this.buttonUpdateUserActivity.BackColor = System.Drawing.Color.LightCoral;
            this.buttonUpdateUserActivity.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonUpdateUserActivity.ForeColor = System.Drawing.Color.White;
            this.buttonUpdateUserActivity.Location = new System.Drawing.Point(240, 269);
            this.buttonUpdateUserActivity.Margin = new System.Windows.Forms.Padding(2);
            this.buttonUpdateUserActivity.Name = "buttonUpdateUserActivity";
            this.buttonUpdateUserActivity.Size = new System.Drawing.Size(100, 32);
            this.buttonUpdateUserActivity.TabIndex = 29;
            this.buttonUpdateUserActivity.Text = "Обновить";
            this.buttonUpdateUserActivity.UseVisualStyleBackColor = false;
            this.buttonUpdateUserActivity.Click += new System.EventHandler(this.buttonUpdateUserActivity_Click);
            // 
            // labelInfo
            // 
            this.labelInfo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelInfo.AutoSize = true;
            this.labelInfo.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelInfo.ForeColor = System.Drawing.Color.LightCoral;
            this.labelInfo.Location = new System.Drawing.Point(84, 34);
            this.labelInfo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelInfo.Name = "labelInfo";
            this.labelInfo.Size = new System.Drawing.Size(384, 46);
            this.labelInfo.TabIndex = 27;
            this.labelInfo.Text = "Эти пользователи взаимодействовали \r\nс вашим профилем";
            this.labelInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonBackUserActivity
            // 
            this.buttonBackUserActivity.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.buttonBackUserActivity.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonBackUserActivity.ForeColor = System.Drawing.Color.White;
            this.buttonBackUserActivity.Location = new System.Drawing.Point(26, 404);
            this.buttonBackUserActivity.Margin = new System.Windows.Forms.Padding(2);
            this.buttonBackUserActivity.Name = "buttonBackUserActivity";
            this.buttonBackUserActivity.Size = new System.Drawing.Size(100, 32);
            this.buttonBackUserActivity.TabIndex = 26;
            this.buttonBackUserActivity.Text = "Назад";
            this.buttonBackUserActivity.UseVisualStyleBackColor = false;
            this.buttonBackUserActivity.Click += new System.EventHandler(this.buttonBackUserActivity_Click);
            // 
            // dataGridViewUserActivity
            // 
            this.dataGridViewUserActivity.AllowUserToOrderColumns = true;
            this.dataGridViewUserActivity.AutoGenerateColumns = false;
            this.dataGridViewUserActivity.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewUserActivity.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.имяпользователяDataGridViewTextBoxColumn,
            this.типвзаимодействияDataGridViewTextBoxColumn,
            this.датаивремяDataGridViewTextBoxColumn});
            this.dataGridViewUserActivity.DataSource = this.getInteractionsBindingSource;
            this.dataGridViewUserActivity.Location = new System.Drawing.Point(55, 103);
            this.dataGridViewUserActivity.Name = "dataGridViewUserActivity";
            this.dataGridViewUserActivity.Size = new System.Drawing.Size(463, 150);
            this.dataGridViewUserActivity.TabIndex = 30;
            // 
            // erimeev_1415_TheMatchDataSet
            // 
            this.erimeev_1415_TheMatchDataSet.DataSetName = "Erimeev_1415_TheMatchDataSet";
            this.erimeev_1415_TheMatchDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // getInteractionsBindingSource
            // 
            this.getInteractionsBindingSource.DataMember = "GetInteractions";
            this.getInteractionsBindingSource.DataSource = this.erimeev_1415_TheMatchDataSet;
            // 
            // getInteractionsTableAdapter
            // 
            this.getInteractionsTableAdapter.ClearBeforeFill = true;
            // 
            // имяпользователяDataGridViewTextBoxColumn
            // 
            this.имяпользователяDataGridViewTextBoxColumn.DataPropertyName = "Имя_пользователя";
            this.имяпользователяDataGridViewTextBoxColumn.HeaderText = "Имя_пользователя";
            this.имяпользователяDataGridViewTextBoxColumn.Name = "имяпользователяDataGridViewTextBoxColumn";
            this.имяпользователяDataGridViewTextBoxColumn.Width = 150;
            // 
            // типвзаимодействияDataGridViewTextBoxColumn
            // 
            this.типвзаимодействияDataGridViewTextBoxColumn.DataPropertyName = "Тип_взаимодействия";
            this.типвзаимодействияDataGridViewTextBoxColumn.HeaderText = "Тип_взаимодействия";
            this.типвзаимодействияDataGridViewTextBoxColumn.Name = "типвзаимодействияDataGridViewTextBoxColumn";
            this.типвзаимодействияDataGridViewTextBoxColumn.Width = 130;
            // 
            // датаивремяDataGridViewTextBoxColumn
            // 
            this.датаивремяDataGridViewTextBoxColumn.DataPropertyName = "Дата_и_время";
            this.датаивремяDataGridViewTextBoxColumn.HeaderText = "Дата_и_время";
            this.датаивремяDataGridViewTextBoxColumn.Name = "датаивремяDataGridViewTextBoxColumn";
            this.датаивремяDataGridViewTextBoxColumn.Width = 140;
            // 
            // Activities
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(582, 450);
            this.Controls.Add(this.dataGridViewUserActivity);
            this.Controls.Add(this.buttonUpdateUserActivity);
            this.Controls.Add(this.labelInfo);
            this.Controls.Add(this.buttonBackUserActivity);
            this.Location = new System.Drawing.Point(21, 81);
            this.Name = "Activities";
            this.Text = "Взаимодействия с вами";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUserActivity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erimeev_1415_TheMatchDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.getInteractionsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonUpdateUserActivity;
        private System.Windows.Forms.Label labelInfo;
        private System.Windows.Forms.Button buttonBackUserActivity;
        private System.Windows.Forms.DataGridView dataGridViewUserActivity;
        private System.Windows.Forms.BindingSource getInteractionsBindingSource;
        private Erimeev_1415_TheMatchDataSet erimeev_1415_TheMatchDataSet;
        private Erimeev_1415_TheMatchDataSetTableAdapters.GetInteractionsTableAdapter getInteractionsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn имяпользователяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn типвзаимодействияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаивремяDataGridViewTextBoxColumn;
    }
}