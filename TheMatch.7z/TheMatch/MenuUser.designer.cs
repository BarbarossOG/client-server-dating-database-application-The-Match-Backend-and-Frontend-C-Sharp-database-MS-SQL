﻿namespace TheMatch
{
    partial class MenuUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonFindUser = new System.Windows.Forms.Button();
            this.buttonInteres = new System.Windows.Forms.Button();
            this.buttonPodpiska = new System.Windows.Forms.Button();
            this.buttonMessage = new System.Windows.Forms.Button();
            this.buttonBackUser = new System.Windows.Forms.Button();
            this.MenuUsers = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonFindUser
            // 
            this.buttonFindUser.BackColor = System.Drawing.Color.LightCoral;
            this.buttonFindUser.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonFindUser.ForeColor = System.Drawing.Color.White;
            this.buttonFindUser.Location = new System.Drawing.Point(154, 223);
            this.buttonFindUser.Margin = new System.Windows.Forms.Padding(2);
            this.buttonFindUser.Name = "buttonFindUser";
            this.buttonFindUser.Size = new System.Drawing.Size(149, 63);
            this.buttonFindUser.TabIndex = 0;
            this.buttonFindUser.Text = "Смотреть анкеты";
            this.buttonFindUser.UseVisualStyleBackColor = false;
            this.buttonFindUser.Click += new System.EventHandler(this.buttonFindUser_Click);
            // 
            // buttonInteres
            // 
            this.buttonInteres.BackColor = System.Drawing.Color.LightCoral;
            this.buttonInteres.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonInteres.ForeColor = System.Drawing.Color.White;
            this.buttonInteres.Location = new System.Drawing.Point(154, 136);
            this.buttonInteres.Margin = new System.Windows.Forms.Padding(2);
            this.buttonInteres.Name = "buttonInteres";
            this.buttonInteres.Size = new System.Drawing.Size(149, 63);
            this.buttonInteres.TabIndex = 1;
            this.buttonInteres.Text = "Ваши увлечения";
            this.buttonInteres.UseVisualStyleBackColor = false;
            this.buttonInteres.Click += new System.EventHandler(this.buttonInteres_Click);
            // 
            // buttonPodpiska
            // 
            this.buttonPodpiska.BackColor = System.Drawing.Color.LightCoral;
            this.buttonPodpiska.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonPodpiska.ForeColor = System.Drawing.Color.White;
            this.buttonPodpiska.Location = new System.Drawing.Point(347, 136);
            this.buttonPodpiska.Margin = new System.Windows.Forms.Padding(2);
            this.buttonPodpiska.Name = "buttonPodpiska";
            this.buttonPodpiska.Size = new System.Drawing.Size(149, 63);
            this.buttonPodpiska.TabIndex = 2;
            this.buttonPodpiska.Text = "Подписка";
            this.buttonPodpiska.UseVisualStyleBackColor = false;
            this.buttonPodpiska.Click += new System.EventHandler(this.buttonPodpiska_Click);
            // 
            // buttonMessage
            // 
            this.buttonMessage.BackColor = System.Drawing.Color.LightCoral;
            this.buttonMessage.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonMessage.ForeColor = System.Drawing.Color.White;
            this.buttonMessage.Location = new System.Drawing.Point(347, 223);
            this.buttonMessage.Margin = new System.Windows.Forms.Padding(2);
            this.buttonMessage.Name = "buttonMessage";
            this.buttonMessage.Size = new System.Drawing.Size(149, 63);
            this.buttonMessage.TabIndex = 4;
            this.buttonMessage.Text = "Cообщения";
            this.buttonMessage.UseVisualStyleBackColor = false;
            this.buttonMessage.Click += new System.EventHandler(this.buttonMessage_Click);
            // 
            // buttonBackUser
            // 
            this.buttonBackUser.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.buttonBackUser.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonBackUser.ForeColor = System.Drawing.Color.White;
            this.buttonBackUser.Location = new System.Drawing.Point(21, 396);
            this.buttonBackUser.Margin = new System.Windows.Forms.Padding(2);
            this.buttonBackUser.Name = "buttonBackUser";
            this.buttonBackUser.Size = new System.Drawing.Size(113, 38);
            this.buttonBackUser.TabIndex = 6;
            this.buttonBackUser.Text = "Назад";
            this.buttonBackUser.UseVisualStyleBackColor = false;
            this.buttonBackUser.Click += new System.EventHandler(this.buttonBackUser_Click);
            // 
            // MenuUsers
            // 
            this.MenuUsers.AutoSize = true;
            this.MenuUsers.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MenuUsers.ForeColor = System.Drawing.Color.LightCoral;
            this.MenuUsers.Location = new System.Drawing.Point(213, 36);
            this.MenuUsers.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.MenuUsers.Name = "MenuUsers";
            this.MenuUsers.Size = new System.Drawing.Size(234, 26);
            this.MenuUsers.TabIndex = 8;
            this.MenuUsers.Text = "Меню пользователя";
            this.MenuUsers.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MenuUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(662, 449);
            this.Controls.Add(this.MenuUsers);
            this.Controls.Add(this.buttonBackUser);
            this.Controls.Add(this.buttonMessage);
            this.Controls.Add(this.buttonPodpiska);
            this.Controls.Add(this.buttonInteres);
            this.Controls.Add(this.buttonFindUser);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "MenuUser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Меню пользователя";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonFindUser;
        private System.Windows.Forms.Button buttonInteres;
        private System.Windows.Forms.Button buttonPodpiska;
        private System.Windows.Forms.Button buttonMessage;
        private System.Windows.Forms.Button buttonBackUser;
        private System.Windows.Forms.Label MenuUsers;
    }
}