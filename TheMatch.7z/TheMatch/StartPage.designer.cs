﻿namespace TheMatch
{
    partial class StartPage
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.WelcomeWords = new System.Windows.Forms.Label();
            this.TheQuest = new System.Windows.Forms.Label();
            this.buttonUser = new System.Windows.Forms.Button();
            this.buttonModerator = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // WelcomeWords
            // 
            this.WelcomeWords.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.WelcomeWords.ForeColor = System.Drawing.Color.LightCoral;
            this.WelcomeWords.Location = new System.Drawing.Point(95, 28);
            this.WelcomeWords.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.WelcomeWords.Name = "WelcomeWords";
            this.WelcomeWords.Size = new System.Drawing.Size(484, 111);
            this.WelcomeWords.TabIndex = 1;
            this.WelcomeWords.Text = "Ты в приложении для знакомств \"Встреча\", \r\nздесь тебя ждёт много интересных знако" +
    "мств и встреч!\r\n";
            this.WelcomeWords.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // TheQuest
            // 
            this.TheQuest.AutoSize = true;
            this.TheQuest.Font = new System.Drawing.Font("Century Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TheQuest.ForeColor = System.Drawing.Color.IndianRed;
            this.TheQuest.Location = new System.Drawing.Point(257, 301);
            this.TheQuest.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.TheQuest.Name = "TheQuest";
            this.TheQuest.Size = new System.Drawing.Size(145, 21);
            this.TheQuest.TabIndex = 3;
            this.TheQuest.Text = "Выбери, кто ты?";
            // 
            // buttonUser
            // 
            this.buttonUser.BackColor = System.Drawing.Color.IndianRed;
            this.buttonUser.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonUser.ForeColor = System.Drawing.Color.White;
            this.buttonUser.Location = new System.Drawing.Point(95, 346);
            this.buttonUser.Margin = new System.Windows.Forms.Padding(2);
            this.buttonUser.Name = "buttonUser";
            this.buttonUser.Size = new System.Drawing.Size(186, 63);
            this.buttonUser.TabIndex = 4;
            this.buttonUser.Text = "Пользователь";
            this.buttonUser.UseVisualStyleBackColor = false;
            this.buttonUser.Click += new System.EventHandler(this.buttonUser_Click);
            // 
            // buttonModerator
            // 
            this.buttonModerator.BackColor = System.Drawing.Color.IndianRed;
            this.buttonModerator.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonModerator.ForeColor = System.Drawing.Color.White;
            this.buttonModerator.Location = new System.Drawing.Point(381, 346);
            this.buttonModerator.Margin = new System.Windows.Forms.Padding(2);
            this.buttonModerator.Name = "buttonModerator";
            this.buttonModerator.Size = new System.Drawing.Size(185, 63);
            this.buttonModerator.TabIndex = 4;
            this.buttonModerator.Text = "Модератор";
            this.buttonModerator.UseVisualStyleBackColor = false;
            this.buttonModerator.Click += new System.EventHandler(this.buttonModerator_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.Image = global::TheMatch.Properties.Resources.icon1;
            this.pictureBox1.Location = new System.Drawing.Point(239, 132);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(203, 160);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // StartPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(662, 449);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.buttonModerator);
            this.Controls.Add(this.buttonUser);
            this.Controls.Add(this.TheQuest);
            this.Controls.Add(this.WelcomeWords);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "StartPage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Встреча";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.StartPage_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label WelcomeWords;
        private System.Windows.Forms.Label TheQuest;
        private System.Windows.Forms.Button buttonUser;
        private System.Windows.Forms.Button buttonModerator;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

