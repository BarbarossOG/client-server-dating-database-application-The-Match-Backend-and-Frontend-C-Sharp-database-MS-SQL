﻿namespace TheMatch
{
    partial class MenuModerator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonEditUser = new System.Windows.Forms.Button();
            this.buttonActionsWithUser = new System.Windows.Forms.Button();
            this.buttonMessageModerating = new System.Windows.Forms.Button();
            this.buttonBackModerator = new System.Windows.Forms.Button();
            this.buttonRank = new System.Windows.Forms.Button();
            this.MenuModerating = new System.Windows.Forms.Label();
            this.buttonPodpiska = new System.Windows.Forms.Button();
            this.buttonOtchet = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonEditUser
            // 
            this.buttonEditUser.BackColor = System.Drawing.Color.White;
            this.buttonEditUser.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonEditUser.ForeColor = System.Drawing.Color.SeaGreen;
            this.buttonEditUser.Location = new System.Drawing.Point(242, 89);
            this.buttonEditUser.Margin = new System.Windows.Forms.Padding(2);
            this.buttonEditUser.Name = "buttonEditUser";
            this.buttonEditUser.Size = new System.Drawing.Size(168, 66);
            this.buttonEditUser.TabIndex = 0;
            this.buttonEditUser.Text = "Редактировать данные пользователя";
            this.buttonEditUser.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonEditUser.UseVisualStyleBackColor = false;
            this.buttonEditUser.Click += new System.EventHandler(this.buttonEditUser_Click);
            // 
            // buttonActionsWithUser
            // 
            this.buttonActionsWithUser.BackColor = System.Drawing.Color.White;
            this.buttonActionsWithUser.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonActionsWithUser.ForeColor = System.Drawing.Color.SeaGreen;
            this.buttonActionsWithUser.Location = new System.Drawing.Point(242, 174);
            this.buttonActionsWithUser.Margin = new System.Windows.Forms.Padding(2);
            this.buttonActionsWithUser.Name = "buttonActionsWithUser";
            this.buttonActionsWithUser.Size = new System.Drawing.Size(168, 66);
            this.buttonActionsWithUser.TabIndex = 1;
            this.buttonActionsWithUser.Text = "Взаимодействие с пользователем";
            this.buttonActionsWithUser.UseVisualStyleBackColor = false;
            // 
            // buttonMessageModerating
            // 
            this.buttonMessageModerating.BackColor = System.Drawing.Color.White;
            this.buttonMessageModerating.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonMessageModerating.ForeColor = System.Drawing.Color.SeaGreen;
            this.buttonMessageModerating.Location = new System.Drawing.Point(242, 259);
            this.buttonMessageModerating.Margin = new System.Windows.Forms.Padding(2);
            this.buttonMessageModerating.Name = "buttonMessageModerating";
            this.buttonMessageModerating.Size = new System.Drawing.Size(168, 66);
            this.buttonMessageModerating.TabIndex = 2;
            this.buttonMessageModerating.Text = "Модерировать сообщения";
            this.buttonMessageModerating.UseVisualStyleBackColor = false;
            // 
            // buttonBackModerator
            // 
            this.buttonBackModerator.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.buttonBackModerator.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonBackModerator.ForeColor = System.Drawing.Color.White;
            this.buttonBackModerator.Location = new System.Drawing.Point(21, 396);
            this.buttonBackModerator.Margin = new System.Windows.Forms.Padding(2);
            this.buttonBackModerator.Name = "buttonBackModerator";
            this.buttonBackModerator.Size = new System.Drawing.Size(112, 38);
            this.buttonBackModerator.TabIndex = 3;
            this.buttonBackModerator.Text = "Назад";
            this.buttonBackModerator.UseVisualStyleBackColor = false;
            this.buttonBackModerator.Click += new System.EventHandler(this.buttonBackModerator_Click);
            // 
            // buttonRank
            // 
            this.buttonRank.BackColor = System.Drawing.Color.White;
            this.buttonRank.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonRank.ForeColor = System.Drawing.Color.SeaGreen;
            this.buttonRank.Location = new System.Drawing.Point(242, 345);
            this.buttonRank.Margin = new System.Windows.Forms.Padding(2);
            this.buttonRank.Name = "buttonRank";
            this.buttonRank.Size = new System.Drawing.Size(168, 66);
            this.buttonRank.TabIndex = 6;
            this.buttonRank.Text = "Должность";
            this.buttonRank.UseVisualStyleBackColor = false;
            // 
            // MenuModerating
            // 
            this.MenuModerating.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.MenuModerating.AutoSize = true;
            this.MenuModerating.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MenuModerating.ForeColor = System.Drawing.Color.SeaGreen;
            this.MenuModerating.Location = new System.Drawing.Point(432, 9);
            this.MenuModerating.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.MenuModerating.Name = "MenuModerating";
            this.MenuModerating.Size = new System.Drawing.Size(229, 26);
            this.MenuModerating.TabIndex = 7;
            this.MenuModerating.Text = "Меню модератора";
            this.MenuModerating.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // buttonPodpiska
            // 
            this.buttonPodpiska.BackColor = System.Drawing.Color.White;
            this.buttonPodpiska.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonPodpiska.ForeColor = System.Drawing.Color.SeaGreen;
            this.buttonPodpiska.Location = new System.Drawing.Point(242, 9);
            this.buttonPodpiska.Margin = new System.Windows.Forms.Padding(2);
            this.buttonPodpiska.Name = "buttonPodpiska";
            this.buttonPodpiska.Size = new System.Drawing.Size(168, 66);
            this.buttonPodpiska.TabIndex = 8;
            this.buttonPodpiska.Text = "Редактировать подписку";
            this.buttonPodpiska.UseVisualStyleBackColor = false;
            // 
            // buttonOtchet
            // 
            this.buttonOtchet.BackColor = System.Drawing.Color.White;
            this.buttonOtchet.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonOtchet.ForeColor = System.Drawing.Color.SeaGreen;
            this.buttonOtchet.Location = new System.Drawing.Point(21, 11);
            this.buttonOtchet.Margin = new System.Windows.Forms.Padding(2);
            this.buttonOtchet.Name = "buttonOtchet";
            this.buttonOtchet.Size = new System.Drawing.Size(168, 66);
            this.buttonOtchet.TabIndex = 9;
            this.buttonOtchet.Text = "Отчёты";
            this.buttonOtchet.UseVisualStyleBackColor = false;
            this.buttonOtchet.Click += new System.EventHandler(this.buttonOtchet_Click);
            // 
            // MenuModerator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(662, 449);
            this.Controls.Add(this.buttonOtchet);
            this.Controls.Add(this.buttonPodpiska);
            this.Controls.Add(this.MenuModerating);
            this.Controls.Add(this.buttonRank);
            this.Controls.Add(this.buttonBackModerator);
            this.Controls.Add(this.buttonMessageModerating);
            this.Controls.Add(this.buttonActionsWithUser);
            this.Controls.Add(this.buttonEditUser);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "MenuModerator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Меню модерации";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonEditUser;
        private System.Windows.Forms.Button buttonActionsWithUser;
        private System.Windows.Forms.Button buttonMessageModerating;
        private System.Windows.Forms.Button buttonBackModerator;
        private System.Windows.Forms.Button buttonRank;
        private System.Windows.Forms.Label MenuModerating;
        private System.Windows.Forms.Button buttonPodpiska;
        private System.Windows.Forms.Button buttonOtchet;
    }
}