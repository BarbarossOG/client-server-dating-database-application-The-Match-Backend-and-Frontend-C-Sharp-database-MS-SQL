﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TheMatch
{
    public partial class BuyPodpiska : Form
    {
        private string connectionString = "Server = DESKTOP-E7PFLIN\\SQLEXPRESS;" +
                                   "Initial Catalog = Erimeev_1415_TheMatch;" +
                                   "Integrated Security = True;";

        public BuyPodpiska()
        {
            InitializeComponent();
        }

        private void buttonBackEditDostup_Click(object sender, EventArgs e)
        {
            MenuUser menuUser = new MenuUser();
            menuUser.Show();
            this.Hide();
        }

        private void BuyPodpiska_Load(object sender, EventArgs e)
        {
            this.подпискаTableAdapter.Fill(this.erimeev_1415_TheMatchDataSet.Подписка);
            LoadSubscriptionsComboBox(); // Загрузка данных в ComboBox при загрузке формы
        }

        private void LoadSubscriptionsComboBox()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("SELECT Название_подписки FROM Подписка", connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            comboBoxVariantPodpiski.Items.Add(reader["Название_подписки"].ToString());
                        }
                    }
                }
            }
        }

        private void buttonBuyPodpisky_Click(object sender, EventArgs e)
        {
            // Получение ID пользователя по Email
            int userID = GetUserIDByEmail(CurrentUser.Email);

            // Проверка, получен ли ID пользователя
            if (userID > 0)
            {
                // Получение названия выбранной подписки
                string selectedSubscription = comboBoxVariantPodpiski.SelectedItem?.ToString();

                if (!string.IsNullOrEmpty(selectedSubscription))
                {
                    // Вызов хранимой процедуры для проверки наличия активной подписки и покупки новой
                    string subscriptionInfo = GetSubscriptionInfoByUserID(userID);

                    if (subscriptionInfo.Contains("Подписка: "))
                    {
                        MessageBox.Show("У вас уже есть активная подписка. Нельзя купить новую, пока старая активна.",
                                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        // Получение ID выбранной подписки
                        int subscriptionID = GetSubscriptionIDByName(selectedSubscription);

                        // Вызов ХП для добавления записи в таблицу Купленные_подписки
                        AddSubscription(userID, subscriptionID);

                        // Вывод сообщения об успешной покупке
                        MessageBox.Show("Подписка успешно куплена!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Выберите подписку для покупки.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                // Вывод сообщения об ошибке при получении ID пользователя
                MessageBox.Show("Ошибка: Не удалось получить ID пользователя.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonCheckPodpisky_Click(object sender, EventArgs e)
        {
            // Получение ID пользователя по Email
            int userID = GetUserIDByEmail(CurrentUser.Email);

            // Проверка, получен ли ID пользователя
            if (userID > 0)
            {
                // Вызов хранимой процедуры для получения информации о подписке
                string subscriptionInfo = GetSubscriptionInfoByUserID(userID);

                // Отображение информации о подписке в текстовом поле
                textBoxCheck.Text = subscriptionInfo;
            }
            else
            {
                // Вывод сообщения об ошибке при получении ID пользователя
                MessageBox.Show("Ошибка: Не удалось получить ID пользователя.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Метод для получения ID пользователя по Email
        private int GetUserIDByEmail(string email)
        {
            int userID = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT ID_Пользователя FROM Пользователи WHERE Электронная_почта = @Email";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Email", email);
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            userID = Convert.ToInt32(reader["ID_Пользователя"]);
                        }
                    }
                }
            }
            return userID;
        }

        // Метод для получения ID подписки по ее названию
        private int GetSubscriptionIDByName(string subscriptionName)
        {
            int subscriptionID = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT ID_Подписки FROM Подписка WHERE Название_подписки = @SubscriptionName";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@SubscriptionName", subscriptionName);
                    connection.Open();

                    object result = command.ExecuteScalar();
                    if (result != null)
                    {
                        subscriptionID = Convert.ToInt32(result);
                    }
                }
            }
            return subscriptionID;
        }

        // Метод для вызова хранимой процедуры и получения информации о подписке по ID пользователя
        private string GetSubscriptionInfoByUserID(int userID)
        {
            string subscriptionInfo = null;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand("GetInfoSubscriptions", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@ID_Пользователя", userID);
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            subscriptionInfo = "Подписка: " +
                                               $"{reader["Название_подписки"]}, " +
                                               $"Дата окончания: {reader["Дата_окончания"]}";
                        }
                        else
                        {
                            subscriptionInfo = "У вас нет активной подписки";
                        }
                    }
                }
            }
            return subscriptionInfo;
        }

        // Метод для вызова ХП AddSubscription
        private void AddSubscription(int userID, int subscriptionID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand("AddSubscription", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@ID_Пользователя", userID);
                    command.Parameters.AddWithValue("@ID_Подписки", subscriptionID);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
