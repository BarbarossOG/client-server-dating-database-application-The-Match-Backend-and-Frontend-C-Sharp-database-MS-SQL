﻿
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TheMatch
{
    public partial class Users : Form
    {
        public Users()
        {
            InitializeComponent();
            LoadData();
        }

        private static string connectionString = "Server = DESKTOP-E7PFLIN\\SQLEXPRESS;" +
                                   "Initial Catalog = Erimeev_1415_TheMatch;" +
                                   "Integrated Security = True;";

        private SqlConnection connection = new SqlConnection(connectionString);

        private void buttonBackUser_Click(object sender, EventArgs e)
        {
            MenuModerator menumoderator = new MenuModerator();
            menumoderator.Show();
            this.Hide();
        }

        private void LoadData()
        {
            try
            {
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Пользователи", connection);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridViewUsers.DataSource = table;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке данных: " + ex.Message);
            }
        }

        private void buttonAddUser_Click(object sender, EventArgs e)
        {
            // Add your code for adding a user here
        }

        private void buttonDeleteUser_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridViewUsers.SelectedRows.Count > 0)
                {
                    // Получение выбранной строки
                    DataGridViewRow selectedRow = dataGridViewUsers.SelectedRows[0];

                    // Получение ID пользователя из выбранной строки
                    int userID = Convert.ToInt32(selectedRow.Cells[0].Value);

                    // Запрос подтверждения перед удалением
                    DialogResult result = MessageBox.Show("Вы уверены, что хотите удалить выбранного пользователя?", "Подтверждение удаления", MessageBoxButtons.YesNo);

                    if (result == DialogResult.Yes)
                    {
                        using (SqlConnection conn = new SqlConnection(connectionString))
                        {
                            conn.Open();

                            using (SqlTransaction transaction = conn.BeginTransaction())
                            {
                                try
                                {
                                    // Удаление пользователя
                                    using (SqlCommand cmd = new SqlCommand("DeleteUser", conn, transaction))
                                    {
                                        cmd.CommandType = CommandType.StoredProcedure;
                                        cmd.Parameters.AddWithValue("@ID_Пользователя", userID);

                                        int rowsAffected = cmd.ExecuteNonQuery();

                                        if (rowsAffected > 0)
                                        {
                                            // Завершение транзакции
                                            transaction.Commit();

                                            MessageBox.Show("Пользователь успешно удален");
                                            UpdateDataGridView();
                                        }
                                        else
                                        {
                                            throw new Exception("Ошибка при удалении пользователя.");
                                        }
                                    }
                                }
                                catch (SqlException ex)
                                {
                                    // Откат транзакции в случае ошибки
                                    transaction.Rollback();

                                    MessageBox.Show("Произошла ошибка при удалении пользователя: " + ex.Message);
                                }
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Выберите строку для удаления");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Произошла ошибка: " + ex.Message);
            }
        }


        private void UpdateDataGridView()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string query = "SELECT * FROM Пользователи";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dataGridViewUsers.DataSource = dataTable;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при обновлении данных: " + ex.Message);
            }
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            UpdateDataGridView();
        }

        private void buttonEditUser_Click(object sender, EventArgs e)
        {
            if (dataGridViewUsers.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridViewUsers.SelectedRows[0];

                int userID = Convert.ToInt32(selectedRow.Cells[0].Value); // assuming ID is in the first column
                string firstName = selectedRow.Cells["Имя"].Value.ToString();
                string sex = selectedRow.Cells["Пол"].Value.ToString();
                int height = Convert.ToInt32(selectedRow.Cells["Рост"].Value);
                DateTime birthDate = Convert.ToDateTime(selectedRow.Cells["Дата_рождения"].Value);
                string location = selectedRow.Cells["Местоположение"].Value.ToString();
                string description = selectedRow.Cells["Описание"].Value.ToString();
                string salaryLevel = selectedRow.Cells["Уровень_заработка"].Value.ToString();
                string housing = selectedRow.Cells["Жильё"].Value.ToString();
                bool hasChildren = Convert.ToBoolean(selectedRow.Cells["Наличие_детей"].Value);
                string email = selectedRow.Cells["Электронная_почта"].Value.ToString();
                string password = selectedRow.Cells["Пароль"].Value.ToString();

                ////EditUsers editUser = new EditUsers();
                //editUser.textBoxFirstName.Text = firstName;
                //editUser.textBoxSex.Text = sex;
                //editUser.textBoxHeight.Text = height.ToString();
                //editUser.dateTimePickerBirthDate.Value = birthDate;
                //editUser.textBoxLocation.Text = location;
                //editUser.textBoxDescription.Text = description;
                //editUser.textBoxSalaryLevel.Text = salaryLevel;
                //editUser.textBoxHousing.Text = housing;
                //editUser.checkBoxHasChildren.Checked = hasChildren;
                //editUser.textBoxEmail.Text = email;
                //editUser.textBoxPassword.Text = password;
                //editUser.ShowDialog();
            }
            else
            {
                MessageBox.Show("Выберите строку для редактирования");
            }
        }

        private void Users_Load(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
