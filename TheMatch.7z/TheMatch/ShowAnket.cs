﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace TheMatch
{
    public partial class ShowAnket : Form
    {
        private static string connectionString = "Server = DESKTOP-E7PFLIN\\SQLEXPRESS;" +
                                   "Initial Catalog = Erimeev_1415_TheMatch;" +
                                   "Integrated Security = True;";
        private SqlConnection connection = new SqlConnection(connectionString);
        private int currentUserID = 0; // Переменная для хранения текущего ID пользователя
        private string initialGender = ""; // Пол начального пользователя

        public ShowAnket()
        {
            InitializeComponent();
            AddComboBoxTypeOcenki();
            initialGender = GetCurrentUserGender(); // Определяем пол текущего пользователя
        }

        private void buttonBackMenuUserAnket_Click(object sender, EventArgs e)
        {
            MenuUser menuuser = new MenuUser();
            menuuser.Show();
            this.Hide();
        }

        private void AddComboBoxTypeOcenki()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT Название_типа FROM Тип_взаимодействия";

                conn.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        comboBoxTypeOcenki.Items.Add(reader["Название_типа"].ToString());
                    }
                }

                conn.Close();
            }
        }

        private void buttonOcenka_Click(object sender, EventArgs e)
        {
            try
            {
                int userID1 = GetUserIDByEmail(CurrentUser.Email);

                // Получение ID типа взаимодействия из выбранного элемента ComboBox
                string typeName = comboBoxTypeOcenki.SelectedItem.ToString();
                int typeID = GetInteractionTypeIDByName(typeName);

                // Получение ID пользователя 2 из текстового поля textBoxID
                int userID2 = Convert.ToInt32(textBoxID.Text);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand("AddOcenkuJurnalPrilozeniya", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@ID_Пользователя1", userID1);
                        command.Parameters.AddWithValue("@ID_Тип_взаимодействия", typeID); // Передаем полученный ID типа взаимодействия
                        command.Parameters.AddWithValue("@ID_Пользователя2", userID2);

                        connection.Open();
                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Оценка успешно добавлена в журнал приложения.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException sqlEx) // Перехватываем исключения SQL Server
            {
                MessageBox.Show("Ошибка SQL: " + sqlEx.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex) // Перехватываем другие исключения
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private int GetUserIDByEmail(string email)
        {
            int userID = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT ID_Пользователя FROM Пользователи WHERE Электронная_почта = @Email";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Email", email);
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            userID = Convert.ToInt32(reader["ID_Пользователя"]);
                        }
                    }
                }
            }
            return userID;
        }

        private int GetInteractionTypeIDByName(string typeName)
        {
            int typeID = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT ID_Тип_взаимодействия FROM Тип_взаимодействия WHERE Название_типа = @TypeName";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@TypeName", typeName);
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            typeID = Convert.ToInt32(reader["ID_Тип_взаимодействия"]);
                        }
                    }
                }
            }
            return typeID;
        }

        private void buttonNextAnketa_Click(object sender, EventArgs e)
        {
            // Проверяем, если текущий пользователь еще не выбран, выбираем первого с противоположным полом
            if (currentUserID == 0)
            {
                // Получаем ID первого пользователя с противоположным полом
                currentUserID = GetNextUserIDWithOppositeGender(0, initialGender);
            }
            else
            {
                // Получаем ID следующего пользователя с противоположным полом
                currentUserID = GetNextUserIDWithOppositeGender(currentUserID, initialGender);
            }

            // Если найден пользователь, обновляем textBoxID и textBoxUserName
            if (currentUserID != 0)
            {
                // Получаем имя и возраст пользователя по его ID
                (string userName, int userAge) = GetUserNameAndAgeByID(currentUserID);

                // Заполняем textBoxID, textBoxUserName и textBoxAge
                textBoxID.Text = currentUserID.ToString();
                textBoxUserName.Text = userName;
                textBoxAge.Text = userAge.ToString();

                // Обновляем изображение
                UpdateUserImage(currentUserID);

                // Загружаем увлечения пользователя
                LoadUserHobbies(currentUserID);
            }
            else
            {
                // Если не найдено больше пользователей, возвращаемся к началу списка
                MessageBox.Show("Достигнут конец списка. Возвращаемся к началу.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                currentUserID = 0; // Сбрасываем текущего пользователя
                textBoxID.Clear();
                textBoxUserName.Clear();
                textBoxAge.Clear();
                pictureBoxAvatar.Image = null; // Очистить изображение
                listBoxUserHobbies.Items.Clear(); // Очистить список увлечений
            }
        }

        private int GetNextUserIDWithOppositeGender(int currentID, string initialGender)
        {
            int nextUserID = 0;
            int currentUserID = GetUserIDByEmail(CurrentUser.Email);

            // Определяем пол для выборки пользователей
            string oppositeGender = (initialGender == "М") ? "Ж" : "М";

            // Получаем следующего пользователя с противоположным полом
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string queryNextUser = @"
                    SELECT TOP 1 ID_Пользователя 
                    FROM Пользователи 
                    WHERE ID_Пользователя > @CurrentID 
                        AND Пол = @OppositeGender 
                        AND NOT EXISTS (
                            SELECT 1 
                            FROM Журнал_приложения 
                            WHERE ID_Пользователя1 = @CurrentUserID 
                                AND ID_Пользователя2 = Пользователи.ID_Пользователя 
                                AND ID_Тип_взаимодействия = 6
                        )
                    ORDER BY ID_Пользователя";
                using (SqlCommand commandNextUser = new SqlCommand(queryNextUser, connection))
                {
                    commandNextUser.Parameters.AddWithValue("@CurrentID", currentID);
                    commandNextUser.Parameters.AddWithValue("@OppositeGender", oppositeGender);
                    commandNextUser.Parameters.AddWithValue("@CurrentUserID", currentUserID);
                    connection.Open();
                    object result = commandNextUser.ExecuteScalar();
                    if (result != null)
                    {
                        nextUserID = Convert.ToInt32(result);
                    }
                }
            }

            return nextUserID;
        }

        private string GetCurrentUserGender()
        {
            string userGender = ""; // Пол текущего пользователя

            // Получаем пол текущего пользователя
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string queryGender = "SELECT Пол FROM Пользователи WHERE Электронная_почта = @Email";
                using (SqlCommand commandGender = new SqlCommand(queryGender, connection))
                {
                    commandGender.Parameters.AddWithValue("@Email", CurrentUser.Email);
                    connection.Open();
                    userGender = commandGender.ExecuteScalar()?.ToString();
                }
            }

            return userGender;
        }

        private (string userName, int userAge) GetUserNameAndAgeByID(int userID)
        {
            string userName = "";
            int userAge = 0;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Имя, Дата_рождения FROM Пользователи WHERE ID_Пользователя = @UserID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            userName = reader["Имя"].ToString();

                            // Вычисляем возраст пользователя
                            DateTime birthDate = Convert.ToDateTime(reader["Дата_рождения"]);
                            DateTime currentDate = DateTime.Today;
                            userAge = currentDate.Year - birthDate.Year;
                            if (birthDate > currentDate.AddYears(-userAge)) userAge--;
                        }
                    }
                }
            }

            return (userName, userAge);
        }

        private void LoadUserHobbies(int userID)
        {
            listBoxUserHobbies.Items.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Название_увлечения FROM Пользователи_Названия_Увлечений WHERE ID_Пользователя = @UserID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            listBoxUserHobbies.Items.Add(reader["Название_увлечения"].ToString());
                        }
                    }
                }
            }
        }

        private void UpdateUserImage(int userID)
        {
            try
            {
                string imageName = initialGender == "М" ? $"Women{userID}" : $"Male{userID}";
                pictureBoxAvatar.Image = (Image)Properties.Resources.ResourceManager.GetObject(imageName);
            }
            catch
            {
                pictureBoxAvatar.Image = null; // Если изображение не найдено, очистить pictureBox
            }
        }

        private void buttonCheckActivity_Click(object sender, EventArgs e)
        {
            Activities activities = new Activities();
            activities.Show();
            this.Hide(); 
        }

        private void buttonVzaimnosti_Click(object sender, EventArgs e)
        {
            Vzaimnosti vzaimno = new Vzaimnosti();
            vzaimno.Show();
            this.Hide(); 
        }
    }
}
