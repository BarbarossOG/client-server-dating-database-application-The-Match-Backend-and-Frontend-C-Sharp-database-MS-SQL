﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TheMatch;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Data.SqlClient;

namespace TheMatch
{
    public partial class UserInter : Form
    {
        // Строка подключения к базе данных 
        private string connectionString = "Server = DESKTOP-E7PFLIN\\SQLEXPRESS;" +
                                          "Initial Catalog = Erimeev_1415_TheMatch;" +
                                          "Integrated Security = True;";


        public UserInter()
        {
            InitializeComponent();
        }

        private void buttonInter_Click(object sender, EventArgs e)
        {
            string login = textBoxLogin.Text;
            string password = textBoxParol.Text;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Пароль, Электронная_почта FROM Пользователи WHERE Электронная_почта = @Login";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Login", login);
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            reader.Read();
                            string storedPassword = reader.GetString(0); // Пароль - первый столбец

                            if (storedPassword == password)
                            {
                                CurrentUser.Email = reader.GetString(1); // Электронная почта - второй столбец
                                MenuUser menuuser = new MenuUser();
                                menuuser.Show();
                                this.Hide();
                            }
                            else
                            {
                                MessageBox.Show("Неправильный пароль", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Логин не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            textBoxParol.Text = "";
        }

        private void buttonBack1_Click(object sender, EventArgs e)
        {
            StartPage startpage = new StartPage();
            startpage.Show();
            this.Hide();
        }
    }
}
