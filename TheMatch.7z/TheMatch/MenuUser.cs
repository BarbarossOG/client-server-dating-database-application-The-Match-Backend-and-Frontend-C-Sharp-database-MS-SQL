﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheMatch
{
    public partial class MenuUser : Form
    {
        public MenuUser()
        {
            InitializeComponent();
        }

        private void buttonBackUser_Click(object sender, EventArgs e)
        {
            StartPage startpage = new StartPage();
            startpage.Show();
            this.Hide();
        }

        private void buttonPodpiska_Click(object sender, EventArgs e)
        {
            BuyPodpiska buypodpiska = new BuyPodpiska();
            buypodpiska.Show();
            this.Hide();

        }

        private void buttonInteres_Click(object sender, EventArgs e)
        {
            Hobbies hobbies = new Hobbies();
            hobbies.Show();
            this.Hide();
        }

        private void buttonFindUser_Click(object sender, EventArgs e)
        {
            ShowAnket showanket = new ShowAnket();
            showanket.Show();
            this.Hide(); 
        }

        private void buttonMessage_Click(object sender, EventArgs e)
        {
            Message message = new Message();
            message.Show();
            this.Hide();
        }
    }
}
