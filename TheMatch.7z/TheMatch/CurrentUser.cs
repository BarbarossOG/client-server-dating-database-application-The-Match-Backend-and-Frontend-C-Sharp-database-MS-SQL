﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheMatch
{
    public static class CurrentUser
    {
        // Свойство для хранения Email пользователя
        public static string Email { get; set; }
    }
}
