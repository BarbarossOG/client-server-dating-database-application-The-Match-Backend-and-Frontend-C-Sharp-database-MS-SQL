﻿namespace TheMatch
{
    partial class Hobbies
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.buttonBackHobbies = new System.Windows.Forms.Button();
            this.labelGetGive = new System.Windows.Forms.Label();
            this.labelHobbies = new System.Windows.Forms.Label();
            this.comboBoxHobbies = new System.Windows.Forms.ComboBox();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.пользователиНазванияУвлеченийBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.erimeev_1415_TheMatchDataSet = new TheMatch.Erimeev_1415_TheMatchDataSet();
            this.пользователи_Названия_УвлеченийTableAdapter = new TheMatch.Erimeev_1415_TheMatchDataSetTableAdapters.Пользователи_Названия_УвлеченийTableAdapter();
            this.listBoxUserHobbies = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиНазванияУвлеченийBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erimeev_1415_TheMatchDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonBackHobbies
            // 
            this.buttonBackHobbies.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.buttonBackHobbies.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonBackHobbies.ForeColor = System.Drawing.Color.White;
            this.buttonBackHobbies.Location = new System.Drawing.Point(21, 396);
            this.buttonBackHobbies.Margin = new System.Windows.Forms.Padding(2);
            this.buttonBackHobbies.Name = "buttonBackHobbies";
            this.buttonBackHobbies.Size = new System.Drawing.Size(100, 32);
            this.buttonBackHobbies.TabIndex = 0;
            this.buttonBackHobbies.Text = "Назад";
            this.buttonBackHobbies.UseVisualStyleBackColor = false;
            this.buttonBackHobbies.Click += new System.EventHandler(this.buttonBackInteres_Click);
            // 
            // labelGetGive
            // 
            this.labelGetGive.AutoSize = true;
            this.labelGetGive.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelGetGive.ForeColor = System.Drawing.Color.LightCoral;
            this.labelGetGive.Location = new System.Drawing.Point(242, 31);
            this.labelGetGive.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelGetGive.Name = "labelGetGive";
            this.labelGetGive.Size = new System.Drawing.Size(165, 23);
            this.labelGetGive.TabIndex = 1;
            this.labelGetGive.Text = "Ваши увлечения";
            // 
            // labelHobbies
            // 
            this.labelHobbies.AutoSize = true;
            this.labelHobbies.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelHobbies.Location = new System.Drawing.Point(507, 33);
            this.labelHobbies.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelHobbies.Name = "labelHobbies";
            this.labelHobbies.Size = new System.Drawing.Size(90, 21);
            this.labelHobbies.TabIndex = 2;
            this.labelHobbies.Text = "Увлечения";
            // 
            // comboBoxHobbies
            // 
            this.comboBoxHobbies.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBoxHobbies.FormattingEnabled = true;
            this.comboBoxHobbies.Location = new System.Drawing.Point(461, 87);
            this.comboBoxHobbies.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxHobbies.Name = "comboBoxHobbies";
            this.comboBoxHobbies.Size = new System.Drawing.Size(171, 28);
            this.comboBoxHobbies.TabIndex = 12;
            // 
            // buttonAdd
            // 
            this.buttonAdd.BackColor = System.Drawing.Color.LightCoral;
            this.buttonAdd.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAdd.ForeColor = System.Drawing.Color.White;
            this.buttonAdd.Location = new System.Drawing.Point(497, 260);
            this.buttonAdd.Margin = new System.Windows.Forms.Padding(2);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(100, 32);
            this.buttonAdd.TabIndex = 15;
            this.buttonAdd.Text = "Добавить";
            this.buttonAdd.UseVisualStyleBackColor = false;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // buttonDelete
            // 
            this.buttonDelete.BackColor = System.Drawing.Color.LightCoral;
            this.buttonDelete.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonDelete.ForeColor = System.Drawing.Color.White;
            this.buttonDelete.Location = new System.Drawing.Point(497, 317);
            this.buttonDelete.Margin = new System.Windows.Forms.Padding(2);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(100, 32);
            this.buttonDelete.TabIndex = 16;
            this.buttonDelete.Text = "Удалить";
            this.buttonDelete.UseVisualStyleBackColor = false;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // пользователиНазванияУвлеченийBindingSource
            // 
            this.пользователиНазванияУвлеченийBindingSource.DataMember = "Пользователи_Названия_Увлечений";
            this.пользователиНазванияУвлеченийBindingSource.DataSource = this.erimeev_1415_TheMatchDataSet;
            // 
            // erimeev_1415_TheMatchDataSet
            // 
            this.erimeev_1415_TheMatchDataSet.DataSetName = "Erimeev_1415_TheMatchDataSet";
            this.erimeev_1415_TheMatchDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // пользователи_Названия_УвлеченийTableAdapter
            // 
            this.пользователи_Названия_УвлеченийTableAdapter.ClearBeforeFill = true;
            // 
            // listBoxUserHobbies
            // 
            this.listBoxUserHobbies.Font = new System.Drawing.Font("Century Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.listBoxUserHobbies.FormattingEnabled = true;
            this.listBoxUserHobbies.ItemHeight = 21;
            this.listBoxUserHobbies.Location = new System.Drawing.Point(214, 87);
            this.listBoxUserHobbies.Name = "listBoxUserHobbies";
            this.listBoxUserHobbies.Size = new System.Drawing.Size(209, 235);
            this.listBoxUserHobbies.TabIndex = 17;
            // 
            // Hobbies
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(662, 449);
            this.Controls.Add(this.listBoxUserHobbies);
            this.Controls.Add(this.buttonDelete);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.comboBoxHobbies);
            this.Controls.Add(this.labelHobbies);
            this.Controls.Add(this.labelGetGive);
            this.Controls.Add(this.buttonBackHobbies);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Hobbies";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Увлечения пользователя";
            this.Load += new System.EventHandler(this.Hobbies_Load);
            ((System.ComponentModel.ISupportInitialize)(this.пользователиНазванияУвлеченийBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erimeev_1415_TheMatchDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBackHobbies;
        private System.Windows.Forms.Label labelGetGive;
        private System.Windows.Forms.Label labelHobbies;
        private System.Windows.Forms.ComboBox comboBoxHobbies;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonDelete;
        private Erimeev_1415_TheMatchDataSet erimeev_1415_TheMatchDataSet;
        private System.Windows.Forms.BindingSource пользователиНазванияУвлеченийBindingSource;
        private Erimeev_1415_TheMatchDataSetTableAdapters.Пользователи_Названия_УвлеченийTableAdapter пользователи_Названия_УвлеченийTableAdapter;
        private System.Windows.Forms.ListBox listBoxUserHobbies;
    }
}