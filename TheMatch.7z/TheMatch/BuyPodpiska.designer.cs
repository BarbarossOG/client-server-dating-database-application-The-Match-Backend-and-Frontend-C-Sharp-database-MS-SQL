﻿namespace TheMatch
{
    partial class BuyPodpiska
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.buttonBackMenuUser = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonCheckPodpisky = new System.Windows.Forms.Button();
            this.buttonBuyPodpisky = new System.Windows.Forms.Button();
            this.textBoxCheck = new System.Windows.Forms.TextBox();
            this.labelCheckPodpiska = new System.Windows.Forms.Label();
            this.comboBoxVariantPodpiski = new System.Windows.Forms.ComboBox();
            this.подпискаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.erimeev_1415_TheMatchDataSet = new TheMatch.Erimeev_1415_TheMatchDataSet();
            this.подпискаTableAdapter = new TheMatch.Erimeev_1415_TheMatchDataSetTableAdapters.ПодпискаTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.названиеподпискиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Срок_действия = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.подпискаBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.подпискаBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erimeev_1415_TheMatchDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.подпискаBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonBackMenuUser
            // 
            this.buttonBackMenuUser.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.buttonBackMenuUser.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonBackMenuUser.ForeColor = System.Drawing.Color.White;
            this.buttonBackMenuUser.Location = new System.Drawing.Point(24, 396);
            this.buttonBackMenuUser.Margin = new System.Windows.Forms.Padding(2);
            this.buttonBackMenuUser.Name = "buttonBackMenuUser";
            this.buttonBackMenuUser.Size = new System.Drawing.Size(110, 35);
            this.buttonBackMenuUser.TabIndex = 0;
            this.buttonBackMenuUser.Text = "Назад";
            this.buttonBackMenuUser.UseVisualStyleBackColor = false;
            this.buttonBackMenuUser.Click += new System.EventHandler(this.buttonBackEditDostup_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(213, 263);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(255, 21);
            this.label3.TabIndex = 1;
            this.label3.Text = "Какую подписку хотите купить?";
            // 
            // buttonCheckPodpisky
            // 
            this.buttonCheckPodpisky.BackColor = System.Drawing.Color.LightCoral;
            this.buttonCheckPodpisky.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonCheckPodpisky.ForeColor = System.Drawing.Color.White;
            this.buttonCheckPodpisky.Location = new System.Drawing.Point(196, 363);
            this.buttonCheckPodpisky.Margin = new System.Windows.Forms.Padding(2);
            this.buttonCheckPodpisky.Name = "buttonCheckPodpisky";
            this.buttonCheckPodpisky.Size = new System.Drawing.Size(105, 44);
            this.buttonCheckPodpisky.TabIndex = 2;
            this.buttonCheckPodpisky.Text = "Проверить";
            this.buttonCheckPodpisky.UseVisualStyleBackColor = false;
            this.buttonCheckPodpisky.Click += new System.EventHandler(this.buttonCheckPodpisky_Click);
            // 
            // buttonBuyPodpisky
            // 
            this.buttonBuyPodpisky.BackColor = System.Drawing.Color.LightCoral;
            this.buttonBuyPodpisky.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonBuyPodpisky.ForeColor = System.Drawing.Color.White;
            this.buttonBuyPodpisky.Location = new System.Drawing.Point(374, 363);
            this.buttonBuyPodpisky.Margin = new System.Windows.Forms.Padding(2);
            this.buttonBuyPodpisky.Name = "buttonBuyPodpisky";
            this.buttonBuyPodpisky.Size = new System.Drawing.Size(105, 44);
            this.buttonBuyPodpisky.TabIndex = 3;
            this.buttonBuyPodpisky.Text = "Купить";
            this.buttonBuyPodpisky.UseVisualStyleBackColor = false;
            this.buttonBuyPodpisky.Click += new System.EventHandler(this.buttonBuyPodpisky_Click);
            // 
            // textBoxCheck
            // 
            this.textBoxCheck.Location = new System.Drawing.Point(124, 58);
            this.textBoxCheck.Name = "textBoxCheck";
            this.textBoxCheck.Size = new System.Drawing.Size(440, 20);
            this.textBoxCheck.TabIndex = 5;
            // 
            // labelCheckPodpiska
            // 
            this.labelCheckPodpiska.AutoSize = true;
            this.labelCheckPodpiska.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelCheckPodpiska.Location = new System.Drawing.Point(213, 24);
            this.labelCheckPodpiska.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelCheckPodpiska.Name = "labelCheckPodpiska";
            this.labelCheckPodpiska.Size = new System.Drawing.Size(284, 21);
            this.labelCheckPodpiska.TabIndex = 6;
            this.labelCheckPodpiska.Text = "Информая об активной подписке";
            // 
            // comboBoxVariantPodpiski
            // 
            this.comboBoxVariantPodpiski.FormattingEnabled = true;
            this.comboBoxVariantPodpiski.Location = new System.Drawing.Point(252, 300);
            this.comboBoxVariantPodpiski.Name = "comboBoxVariantPodpiski";
            this.comboBoxVariantPodpiski.Size = new System.Drawing.Size(158, 21);
            this.comboBoxVariantPodpiski.TabIndex = 7;
            // 
            // подпискаBindingSource
            // 
            this.подпискаBindingSource.DataMember = "Подписка";
            this.подпискаBindingSource.DataSource = this.erimeev_1415_TheMatchDataSet;
            // 
            // erimeev_1415_TheMatchDataSet
            // 
            this.erimeev_1415_TheMatchDataSet.DataSetName = "Erimeev_1415_TheMatchDataSet";
            this.erimeev_1415_TheMatchDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // подпискаTableAdapter
            // 
            this.подпискаTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.названиеподпискиDataGridViewTextBoxColumn,
            this.ценаDataGridViewTextBoxColumn,
            this.Срок_действия});
            this.dataGridView1.DataSource = this.подпискаBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(124, 94);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(440, 153);
            this.dataGridView1.TabIndex = 8;
            // 
            // названиеподпискиDataGridViewTextBoxColumn
            // 
            this.названиеподпискиDataGridViewTextBoxColumn.DataPropertyName = "Название_подписки";
            this.названиеподпискиDataGridViewTextBoxColumn.HeaderText = "Название_подписки";
            this.названиеподпискиDataGridViewTextBoxColumn.Name = "названиеподпискиDataGridViewTextBoxColumn";
            this.названиеподпискиDataGridViewTextBoxColumn.Width = 150;
            // 
            // ценаDataGridViewTextBoxColumn
            // 
            this.ценаDataGridViewTextBoxColumn.DataPropertyName = "Цена";
            this.ценаDataGridViewTextBoxColumn.HeaderText = "Цена";
            this.ценаDataGridViewTextBoxColumn.Name = "ценаDataGridViewTextBoxColumn";
            // 
            // Срок_действия
            // 
            this.Срок_действия.DataPropertyName = "Срок_действия";
            this.Срок_действия.FillWeight = 150F;
            this.Срок_действия.HeaderText = "Срок_действия_месяцев";
            this.Срок_действия.Name = "Срок_действия";
            this.Срок_действия.Width = 150;
            // 
            // подпискаBindingSource1
            // 
            this.подпискаBindingSource1.DataMember = "Подписка";
            this.подпискаBindingSource1.DataSource = this.erimeev_1415_TheMatchDataSet;
            // 
            // BuyPodpiska
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(663, 449);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.comboBoxVariantPodpiski);
            this.Controls.Add(this.labelCheckPodpiska);
            this.Controls.Add(this.textBoxCheck);
            this.Controls.Add(this.buttonBuyPodpisky);
            this.Controls.Add(this.buttonCheckPodpisky);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.buttonBackMenuUser);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "BuyPodpiska";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Подписка";
            this.Load += new System.EventHandler(this.BuyPodpiska_Load);
            ((System.ComponentModel.ISupportInitialize)(this.подпискаBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erimeev_1415_TheMatchDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.подпискаBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBackMenuUser;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonCheckPodpisky;
        private System.Windows.Forms.Button buttonBuyPodpisky;
        private System.Windows.Forms.TextBox textBoxCheck;
        private System.Windows.Forms.Label labelCheckPodpiska;
        private System.Windows.Forms.ComboBox comboBoxVariantPodpiski;
        private Erimeev_1415_TheMatchDataSet erimeev_1415_TheMatchDataSet;
        private System.Windows.Forms.BindingSource подпискаBindingSource;
        private Erimeev_1415_TheMatchDataSetTableAdapters.ПодпискаTableAdapter подпискаTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource подпискаBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеподпискиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Срок_действия;
    }
}