﻿namespace TheMatch
{
    partial class ModeratorInter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelParol = new System.Windows.Forms.Label();
            this.textBoxParol = new System.Windows.Forms.TextBox();
            this.buttonInter = new System.Windows.Forms.Button();
            this.buttonBack1 = new System.Windows.Forms.Button();
            this.labelLogin = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxLogin = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // labelParol
            // 
            this.labelParol.AutoSize = true;
            this.labelParol.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelParol.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.labelParol.Location = new System.Drawing.Point(283, 263);
            this.labelParol.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelParol.Name = "labelParol";
            this.labelParol.Size = new System.Drawing.Size(86, 23);
            this.labelParol.TabIndex = 1;
            this.labelParol.Text = "Пароль:";
            // 
            // textBoxParol
            // 
            this.textBoxParol.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxParol.Location = new System.Drawing.Point(204, 301);
            this.textBoxParol.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxParol.Name = "textBoxParol";
            this.textBoxParol.PasswordChar = '*';
            this.textBoxParol.Size = new System.Drawing.Size(240, 27);
            this.textBoxParol.TabIndex = 2;
            // 
            // buttonInter
            // 
            this.buttonInter.BackColor = System.Drawing.Color.SeaGreen;
            this.buttonInter.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonInter.ForeColor = System.Drawing.Color.White;
            this.buttonInter.Location = new System.Drawing.Point(402, 367);
            this.buttonInter.Margin = new System.Windows.Forms.Padding(2);
            this.buttonInter.Name = "buttonInter";
            this.buttonInter.Size = new System.Drawing.Size(130, 45);
            this.buttonInter.TabIndex = 3;
            this.buttonInter.Text = "Войти";
            this.buttonInter.UseVisualStyleBackColor = false;
            this.buttonInter.Click += new System.EventHandler(this.buttonInter_Click);
            // 
            // buttonBack1
            // 
            this.buttonBack1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.buttonBack1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonBack1.ForeColor = System.Drawing.Color.White;
            this.buttonBack1.Location = new System.Drawing.Point(129, 367);
            this.buttonBack1.Margin = new System.Windows.Forms.Padding(2);
            this.buttonBack1.Name = "buttonBack1";
            this.buttonBack1.Size = new System.Drawing.Size(130, 45);
            this.buttonBack1.TabIndex = 4;
            this.buttonBack1.Text = "Назад";
            this.buttonBack1.UseVisualStyleBackColor = false;
            this.buttonBack1.Click += new System.EventHandler(this.buttonBack1_Click);
            // 
            // labelLogin
            // 
            this.labelLogin.AutoSize = true;
            this.labelLogin.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelLogin.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.labelLogin.Location = new System.Drawing.Point(283, 164);
            this.labelLogin.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelLogin.Name = "labelLogin";
            this.labelLogin.Size = new System.Drawing.Size(70, 23);
            this.labelLogin.TabIndex = 5;
            this.labelLogin.Text = "Логин:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.label1.Location = new System.Drawing.Point(198, 60);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(260, 23);
            this.label1.TabIndex = 7;
            this.label1.Text = "Вход в панель модерации";
            // 
            // textBoxLogin
            // 
            this.textBoxLogin.Location = new System.Drawing.Point(202, 216);
            this.textBoxLogin.Name = "textBoxLogin";
            this.textBoxLogin.Size = new System.Drawing.Size(240, 20);
            this.textBoxLogin.TabIndex = 9;
            // 
            // ModeratorInter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(662, 449);
            this.Controls.Add(this.textBoxLogin);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelLogin);
            this.Controls.Add(this.buttonBack1);
            this.Controls.Add(this.buttonInter);
            this.Controls.Add(this.textBoxParol);
            this.Controls.Add(this.labelParol);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ModeratorInter";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Авторизация модератора";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelParol;
        private System.Windows.Forms.TextBox textBoxParol;
        private System.Windows.Forms.Button buttonInter;
        private System.Windows.Forms.Button buttonBack1;
        private System.Windows.Forms.Label labelLogin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxLogin;
    }
}